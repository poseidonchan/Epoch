import Foundation

public enum SessionLifecycle: String, Codable, CaseIterable, Sendable {
    case active
    case archived
}

public struct Project: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public var name: String
    public let createdAt: Date
    public var updatedAt: Date

    public init(id: UUID = UUID(), name: String, createdAt: Date = .now, updatedAt: Date = .now) {
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public struct Session: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let projectID: UUID
    public var title: String
    public var lifecycle: SessionLifecycle
    public let createdAt: Date
    public var updatedAt: Date

    public init(
        id: UUID = UUID(),
        projectID: UUID,
        title: String,
        lifecycle: SessionLifecycle = .active,
        createdAt: Date = .now,
        updatedAt: Date = .now
    ) {
        self.id = id
        self.projectID = projectID
        self.title = title
        self.lifecycle = lifecycle
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
}

public enum ArtifactKind: String, Codable, CaseIterable, Sendable {
    case notebook
    case python
    case image
    case text
    case json
    case log
    case unknown

    public static func infer(from path: String) -> ArtifactKind {
        let ext = URL(fileURLWithPath: path).pathExtension.lowercased()
        switch ext {
        case "ipynb":
            return .notebook
        case "py":
            return .python
        case "png", "jpg", "jpeg":
            return .image
        case "txt", "md":
            return .text
        case "json":
            return .json
        case "log":
            return .log
        default:
            return .unknown
        }
    }
}

public enum ArtifactOrigin: String, Codable, CaseIterable, Sendable {
    case userUpload = "user_upload"
    case generated = "generated"
}

public struct Artifact: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let projectID: UUID
    public var path: String
    public var kind: ArtifactKind
    public var origin: ArtifactOrigin
    public var modifiedAt: Date
    public var sizeBytes: Int?
    public var createdBySessionID: UUID?
    public var createdByRunID: UUID?

    public init(
        id: UUID = UUID(),
        projectID: UUID,
        path: String,
        kind: ArtifactKind? = nil,
        origin: ArtifactOrigin = .generated,
        modifiedAt: Date = .now,
        sizeBytes: Int? = nil,
        createdBySessionID: UUID? = nil,
        createdByRunID: UUID? = nil
    ) {
        self.id = id
        self.projectID = projectID
        self.path = path
        self.kind = kind ?? ArtifactKind.infer(from: path)
        self.origin = origin
        self.modifiedAt = modifiedAt
        self.sizeBytes = sizeBytes
        self.createdBySessionID = createdBySessionID
        self.createdByRunID = createdByRunID
    }
}

public enum RunStatus: String, Codable, CaseIterable, Sendable {
    case queued
    case running
    case succeeded
    case failed
    case canceled
}

public enum RunActionType: String, Codable, CaseIterable, Sendable {
    case toolCall
    case command
    case output
    case info
}

public struct RunActionEvent: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let timestamp: Date
    public var type: RunActionType
    public var summary: String
    public var detail: String

    public init(
        id: UUID = UUID(),
        timestamp: Date = .now,
        type: RunActionType,
        summary: String,
        detail: String
    ) {
        self.id = id
        self.timestamp = timestamp
        self.type = type
        self.summary = summary
        self.detail = detail
    }
}

public struct RunRecord: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let projectID: UUID
    public var sessionID: UUID?
    public var status: RunStatus
    public let initiatedAt: Date
    public var completedAt: Date?
    public var currentStep: Int
    public var totalSteps: Int
    public var logSnippet: String
    public var stepTitles: [String]
    public var stepDetails: [String]
    public var activity: [RunActionEvent]
    public var producedArtifactPaths: [String]
    public var hpcJobID: String?

    public init(
        id: UUID = UUID(),
        projectID: UUID,
        sessionID: UUID?,
        status: RunStatus,
        initiatedAt: Date = .now,
        completedAt: Date? = nil,
        currentStep: Int,
        totalSteps: Int,
        logSnippet: String,
        stepTitles: [String],
        stepDetails: [String] = [],
        activity: [RunActionEvent] = [],
        producedArtifactPaths: [String] = [],
        hpcJobID: String? = nil
    ) {
        self.id = id
        self.projectID = projectID
        self.sessionID = sessionID
        self.status = status
        self.initiatedAt = initiatedAt
        self.completedAt = completedAt
        self.currentStep = currentStep
        self.totalSteps = totalSteps
        self.logSnippet = logSnippet
        self.stepTitles = stepTitles
        self.stepDetails = stepDetails
        self.activity = activity
        self.producedArtifactPaths = producedArtifactPaths
        self.hpcJobID = hpcJobID
    }

    private enum CodingKeys: String, CodingKey {
        case id
        case projectID
        case sessionID
        case status
        case initiatedAt
        case completedAt
        case currentStep
        case totalSteps
        case logSnippet
        case stepTitles
        case stepDetails
        case activity
        case producedArtifactPaths
        case hpcJobID = "hpcJobId"
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(UUID.self, forKey: .id)
        projectID = try container.decode(UUID.self, forKey: .projectID)
        sessionID = try container.decodeIfPresent(UUID.self, forKey: .sessionID)
        status = try container.decode(RunStatus.self, forKey: .status)
        initiatedAt = try container.decode(Date.self, forKey: .initiatedAt)
        completedAt = try container.decodeIfPresent(Date.self, forKey: .completedAt)
        currentStep = try container.decode(Int.self, forKey: .currentStep)
        totalSteps = try container.decode(Int.self, forKey: .totalSteps)
        logSnippet = try container.decode(String.self, forKey: .logSnippet)
        stepTitles = try container.decodeIfPresent([String].self, forKey: .stepTitles) ?? []
        stepDetails = try container.decodeIfPresent([String].self, forKey: .stepDetails) ?? []
        activity = try container.decodeIfPresent([RunActionEvent].self, forKey: .activity) ?? []
        producedArtifactPaths = try container.decodeIfPresent([String].self, forKey: .producedArtifactPaths) ?? []
        hpcJobID = try container.decodeIfPresent(String.self, forKey: .hpcJobID)
    }
}

public enum ToolRuntime: String, Codable, CaseIterable, Sendable {
    case python = "Python"
    case shell = "Shell"
    case download = "Download"
    case hpcJob = "HPC Job"
    case notebook = "Notebook"
}

public enum PlanRiskFlag: String, Codable, CaseIterable, Sendable {
    case networkAccess = "Network access"
    case largeDownload = "Large download"
    case overwriteExisting = "Overwrite existing files"
}

public struct PlanStep: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public var title: String
    public var runtime: ToolRuntime
    public var inputs: [String]
    public var outputs: [String]
    public var riskFlags: [PlanRiskFlag]

    public init(
        id: UUID = UUID(),
        title: String,
        runtime: ToolRuntime,
        inputs: [String],
        outputs: [String],
        riskFlags: [PlanRiskFlag] = []
    ) {
        self.id = id
        self.title = title
        self.runtime = runtime
        self.inputs = inputs
        self.outputs = outputs
        self.riskFlags = riskFlags
    }
}

public struct ExecutionPlan: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let projectID: UUID
    public let sessionID: UUID
    public let createdAt: Date
    public var steps: [PlanStep]

    public init(
        id: UUID = UUID(),
        projectID: UUID,
        sessionID: UUID,
        createdAt: Date = .now,
        steps: [PlanStep]
    ) {
        self.id = id
        self.projectID = projectID
        self.sessionID = sessionID
        self.createdAt = createdAt
        self.steps = steps
    }
}

public enum ThinkingLevel: String, Codable, CaseIterable, Sendable {
    case minimal
    case low
    case medium
    case high
    case xhigh
}

public enum SessionPermissionLevel: String, Codable, CaseIterable, Sendable {
    case `default` = "default"
    case full = "full"
}

public struct GatewayModelInfo: Identifiable, Hashable, Codable, Sendable {
    public let id: String
    public var name: String
    public var reasoning: Bool

    public init(id: String, name: String, reasoning: Bool) {
        self.id = id
        self.name = name
        self.reasoning = reasoning
    }
}

public struct ModelsCurrentResponse: Hashable, Codable, Sendable {
    public var provider: String
    public var defaultModelId: String
    public var models: [GatewayModelInfo]
    public var thinkingLevels: [ThinkingLevel]

    public init(provider: String, defaultModelId: String, models: [GatewayModelInfo], thinkingLevels: [ThinkingLevel]) {
        self.provider = provider
        self.defaultModelId = defaultModelId
        self.models = models
        self.thinkingLevels = thinkingLevels
    }
}

public struct SessionContextState: Hashable, Codable, Sendable {
    public var projectId: UUID
    public var sessionId: UUID
    public var permissionLevel: String?
    public var modelId: String?
    public var contextWindowTokens: Int?
    public var usedInputTokens: Int?
    public var usedTokens: Int?
    public var remainingTokens: Int?
    public var updatedAt: Date?

    public init(
        projectId: UUID,
        sessionId: UUID,
        permissionLevel: String? = nil,
        modelId: String? = nil,
        contextWindowTokens: Int? = nil,
        usedInputTokens: Int? = nil,
        usedTokens: Int? = nil,
        remainingTokens: Int? = nil,
        updatedAt: Date? = nil
    ) {
        self.projectId = projectId
        self.sessionId = sessionId
        self.permissionLevel = permissionLevel
        self.modelId = modelId
        self.contextWindowTokens = contextWindowTokens
        self.usedInputTokens = usedInputTokens
        self.usedTokens = usedTokens
        self.remainingTokens = remainingTokens
        self.updatedAt = updatedAt
    }
}

public struct JudgmentOption: Hashable, Codable, Sendable {
    public var label: String
    public var description: String

    public init(label: String, description: String) {
        self.label = label
        self.description = description
    }
}

public struct JudgmentQuestion: Hashable, Codable, Sendable {
    public var id: String
    public var header: String
    public var question: String
    public var options: [JudgmentOption]
    public var allowFreeform: Bool

    public init(
        id: String,
        header: String,
        question: String,
        options: [JudgmentOption],
        allowFreeform: Bool
    ) {
        self.id = id
        self.header = header
        self.question = question
        self.options = options
        self.allowFreeform = allowFreeform
    }
}

public struct JudgmentPrompt: Hashable, Codable, Sendable {
    public var questions: [JudgmentQuestion]

    public init(questions: [JudgmentQuestion]) {
        self.questions = questions
    }
}

public struct JudgmentResponses: Hashable, Codable, Sendable {
    public var answers: [String: String]?
    public var freeform: [String: String]?

    public init(answers: [String: String]? = nil, freeform: [String: String]? = nil) {
        self.answers = answers
        self.freeform = freeform
    }
}

public struct PendingApproval: Identifiable, Hashable, Sendable {
    public var id: UUID { planId }
    public var planId: UUID
    public var projectId: UUID
    public var sessionId: UUID
    public var agentRunId: UUID
    public var plan: ExecutionPlan
    public var required: Bool
    public var judgment: JudgmentPrompt?

    public init(
        planId: UUID,
        projectId: UUID,
        sessionId: UUID,
        agentRunId: UUID,
        plan: ExecutionPlan,
        required: Bool,
        judgment: JudgmentPrompt?
    ) {
        self.planId = planId
        self.projectId = projectId
        self.sessionId = sessionId
        self.agentRunId = agentRunId
        self.plan = plan
        self.required = required
        self.judgment = judgment
    }
}

public struct ChatArtifactReference: Hashable, Codable, Sendable {
    public var displayText: String
    public var projectID: UUID
    public var path: String
    public var artifactID: UUID?

    public init(displayText: String, projectID: UUID, path: String, artifactID: UUID? = nil) {
        self.displayText = displayText
        self.projectID = projectID
        self.path = path
        self.artifactID = artifactID
    }
}

public enum MessageRole: String, Codable, CaseIterable, Sendable {
    case user
    case assistant
    case tool
    case system
}

public struct ChatMessage: Identifiable, Hashable, Codable, Sendable {
    public let id: UUID
    public let sessionID: UUID
    public var role: MessageRole
    public var text: String
    public let createdAt: Date
    public var artifactRefs: [ChatArtifactReference]
    public var proposedPlan: ExecutionPlan?
    public var linkedRunID: UUID?

    public init(
        id: UUID = UUID(),
        sessionID: UUID,
        role: MessageRole,
        text: String,
        createdAt: Date = .now,
        artifactRefs: [ChatArtifactReference] = [],
        proposedPlan: ExecutionPlan? = nil,
        linkedRunID: UUID? = nil
    ) {
        self.id = id
        self.sessionID = sessionID
        self.role = role
        self.text = text
        self.createdAt = createdAt
        self.artifactRefs = artifactRefs
        self.proposedPlan = proposedPlan
        self.linkedRunID = linkedRunID
    }
}

public struct HPCStatus: Hashable, Codable, Sendable {
    public var partition: String?
    public var account: String?
    public var qos: String?
    public var runningJobs: Int
    public var pendingJobs: Int
    public var limit: Tres?
    public var inUse: Tres?
    public var available: Tres?
    public var updatedAt: Date?

    public init(
        partition: String? = nil,
        account: String? = nil,
        qos: String? = nil,
        runningJobs: Int,
        pendingJobs: Int,
        limit: Tres? = nil,
        inUse: Tres? = nil,
        available: Tres? = nil,
        updatedAt: Date? = nil
    ) {
        self.partition = partition
        self.account = account
        self.qos = qos
        self.runningJobs = runningJobs
        self.pendingJobs = pendingJobs
        self.limit = limit
        self.inUse = inUse
        self.available = available
        self.updatedAt = updatedAt
    }

    public struct Tres: Hashable, Codable, Sendable {
        public var cpu: Int?
        public var memMB: Int?
        public var gpus: Int?

        public init(cpu: Int? = nil, memMB: Int? = nil, gpus: Int? = nil) {
            self.cpu = cpu
            self.memMB = memMB
            self.gpus = gpus
        }
    }
}

public struct ResourceStatus: Hashable, Codable, Sendable {
    public var computeConnected: Bool
    public var queueDepth: Int
    public var storageUsedPercent: Double
    public var cpuPercent: Double
    public var ramPercent: Double
    public var hpc: HPCStatus?

    public init(
        computeConnected: Bool,
        queueDepth: Int,
        storageUsedPercent: Double,
        cpuPercent: Double,
        ramPercent: Double,
        hpc: HPCStatus? = nil
    ) {
        self.computeConnected = computeConnected
        self.queueDepth = queueDepth
        self.storageUsedPercent = storageUsedPercent
        self.cpuPercent = cpuPercent
        self.ramPercent = ramPercent
        self.hpc = hpc
    }

    public static let placeholder = ResourceStatus(
        computeConnected: false,
        queueDepth: 0,
        storageUsedPercent: 0,
        cpuPercent: 0,
        ramPercent: 0,
        hpc: nil
    )
}

public enum ResultsTab: String, CaseIterable, Codable, Sendable {
    case artifacts = "Artifacts"
    case runs = "Runs"
}

public enum AppContext: Hashable, Sendable {
    case home
    case project(projectID: UUID)
    case session(projectID: UUID, sessionID: UUID)
}

public struct HomeTaskRow: Identifiable, Hashable, Sendable {
    public let id: UUID
    public let projectID: UUID
    public let projectName: String
    public let runID: UUID
    public let title: String
    public let status: RunStatus
    public let progressText: String

    public init(
        id: UUID = UUID(),
        projectID: UUID,
        projectName: String,
        runID: UUID,
        title: String,
        status: RunStatus,
        progressText: String
    ) {
        self.id = id
        self.projectID = projectID
        self.projectName = projectName
        self.runID = runID
        self.title = title
        self.status = status
        self.progressText = progressText
    }
}
