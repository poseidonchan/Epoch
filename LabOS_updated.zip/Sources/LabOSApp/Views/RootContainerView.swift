#if os(iOS)
import LabOSCore
import SwiftUI

struct RootContainerView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        GeometryReader { proxy in
            let leftWidth = min(proxy.size.width * 0.82, 340)
            let canPresentLeftPanel = !isSessionContext
            let isLeftPanelVisible = store.isLeftPanelOpen && canPresentLeftPanel

            ZStack(alignment: .leading) {
                currentContent
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .offset(x: isLeftPanelVisible ? leftWidth : 0)
                    .overlay {
                        if isLeftPanelVisible {
                            Color.black.opacity(0.22)
                                .ignoresSafeArea()
                                .onTapGesture {
                                    withAnimation(.spring(response: 0.28, dampingFraction: 0.88)) {
                                        store.closeLeftPanel()
                                    }
                            }
                        }
                    }
                    .highPriorityGesture(mainEdgeGesture())

                if isLeftPanelVisible {
                    leftPanel
                        .frame(width: leftWidth)
                        .transition(.move(edge: .leading))
                        .gesture(leftPanelCloseGesture)
                }
            }
            .animation(.spring(response: 0.28, dampingFraction: 0.88), value: isLeftPanelVisible)
            .background(Color(.systemBackground))
            .ignoresSafeArea(edges: .bottom)
            .onChange(of: store.context) { _, newContext in
                guard case .session = newContext, store.isLeftPanelOpen else { return }
                withAnimation(.spring(response: 0.25, dampingFraction: 0.9)) {
                    store.closeLeftPanel()
                }
            }
            .fullScreenCover(
                isPresented: Binding(
                    get: { store.isRightPanelOpen },
                    set: { isPresented in
                        if !isPresented {
                            store.closeResults()
                        }
                    }
                )
            ) {
                ResultsPageView()
                    .environmentObject(store)
            }
        }
    }

    private var isSessionContext: Bool {
        if case .session = store.context {
            return true
        }
        return false
    }

    @ViewBuilder
    private var currentContent: some View {
        switch store.context {
        case .home:
            HomeView()
        case let .project(projectID):
            ProjectPageView(projectID: projectID)
        case let .session(projectID, sessionID):
            SessionChatView(projectID: projectID, sessionID: sessionID)
        }
    }

    @ViewBuilder
    private var leftPanel: some View {
        switch store.context {
        case .home, .project:
            ProjectsDrawerView()
                .background(Color(.secondarySystemBackground))
        case let .session(projectID, _):
            SessionsDrawerView(projectID: projectID)
                .background(Color(.secondarySystemBackground))
        }
    }

    private func mainEdgeGesture() -> some Gesture {
        DragGesture(minimumDistance: 18, coordinateSpace: .local)
            .onEnded { value in
                let startX = value.startLocation.x
                let deltaX = value.translation.width

                if store.isLeftPanelOpen, deltaX < -70 {
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.9)) {
                        store.closeLeftPanel()
                    }
                    return
                }

                if !isSessionContext, startX < 28, deltaX > 70 {
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.9)) {
                        store.openLeftPanel()
                    }
                }
            }
    }

    private var leftPanelCloseGesture: some Gesture {
        DragGesture(minimumDistance: 18)
            .onEnded { value in
                if value.translation.width < -60 {
                    withAnimation(.spring(response: 0.24, dampingFraction: 0.9)) {
                        store.closeLeftPanel()
                    }
                }
            }
    }
}
#endif
