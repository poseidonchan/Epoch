#if os(iOS)
import MarkdownUI
import SwiftUI
import WebKit

struct MarkdownMathView: View {
    let markdown: String

    @Environment(\.colorScheme) private var colorScheme
    @State private var webHeight: CGFloat = 20

    var body: some View {
        if MarkdownMathWebView.canRender {
            MarkdownMathWebView(markdown: markdown, height: $webHeight)
                .frame(height: max(20, webHeight))
        } else {
            Markdown(MarkdownMathPreprocessor.prepareForRendering(markdown))
                .markdownTheme(.gitHub)
                .markdownTextStyle(\.code) {
                    FontFamilyVariant(.monospaced)
                    FontSize(.em(0.9))
                    ForegroundColor(.primary)
                    BackgroundColor(Color.black.opacity(colorScheme == .dark ? 0.22 : 0.06))
                }
                .markdownBlockStyle(\.codeBlock) { configuration in
                    ScrollView(.horizontal) {
                        configuration.label
                            .padding(12)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color(.secondarySystemBackground))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .strokeBorder(Color.primary.opacity(colorScheme == .dark ? 0.14 : 0.08))
                    )
                }
                .textSelection(.enabled)
        }
    }
}

private struct MarkdownMathWebView: UIViewRepresentable {
    let markdown: String
    @Binding var height: CGFloat

    @Environment(\.colorScheme) private var colorScheme

    static var canRender: Bool {
        assetURLs(bundle: resourceBundle) != nil
    }

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true

        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.isOpaque = false
        view.backgroundColor = .clear
        view.scrollView.backgroundColor = .clear
        view.scrollView.isScrollEnabled = false
        view.scrollView.bounces = false
        return view
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        guard let urls = Self.assetURLs(bundle: Self.resourceBundle) else { return }

        let prepared = MarkdownMathPreprocessor.prepareForRendering(markdown)
        let signature = "\(colorScheme == .dark ? "dark" : "light")::\(prepared)"
        if context.coordinator.lastSignature == signature {
            return
        }
        context.coordinator.lastSignature = signature

        let escaped = Self.escapeHTML(prepared)
        let highlightCSS = (colorScheme == .dark ? urls.highlightDarkCSS : urls.highlightLightCSS)?.absoluteString ?? ""
        let highlightLinkHTML = highlightCSS.isEmpty ? "" : "<link rel=\"stylesheet\" href=\"\(highlightCSS)\">"
        let highlightScriptsHTML = [
            urls.highlightScript,
            urls.highlightPythonScript,
            urls.highlightRScript,
        ]
        .compactMap { $0?.absoluteString }
        .map { "<script src=\"\($0)\"></script>" }
        .joined(separator: "\n")

        let html = """
        <!doctype html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
              :root { color-scheme: \(colorScheme == .dark ? "dark" : "light"); }
              body {
                margin: 0;
                padding: 0;
                background: transparent;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
                font-size: 16px;
                line-height: 1.45;
                color: \(colorScheme == .dark ? "#FFFFFF" : "#111111");
              }
              #content {
                padding: 0;
                word-wrap: break-word;
                overflow-wrap: anywhere;
              }
              h1,h2,h3,h4 { margin: 0.75em 0 0.4em; }
              p { margin: 0.55em 0; }
              ul,ol { margin: 0.55em 0 0.55em 1.2em; padding: 0; }
              li { margin: 0.25em 0; }
              blockquote {
                margin: 0.6em 0;
                padding: 0.15em 0 0.15em 0.9em;
                border-left: 3px solid rgba(120,120,120,0.35);
                color: rgba(127,127,127,0.95);
              }
              pre {
                margin: 0.7em 0;
                padding: 12px;
                overflow: auto;
                border-radius: 12px;
                background: rgba(127,127,127,\(colorScheme == .dark ? "0.16" : "0.10"));
                border: 1px solid rgba(127,127,127,\(colorScheme == .dark ? "0.18" : "0.14"));
              }
              code {
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
                font-size: 0.92em;
              }
              :not(pre) > code {
                padding: 0.16em 0.33em;
                border-radius: 6px;
                background: rgba(127,127,127,\(colorScheme == .dark ? "0.18" : "0.12"));
              }
              table { border-collapse: collapse; margin: 0.75em 0; width: 100%; }
              th, td { border: 1px solid rgba(127,127,127,\(colorScheme == .dark ? "0.28" : "0.22")); padding: 6px 8px; }
              img { max-width: 100%; height: auto; }
              .md-error { white-space: pre-wrap; }
            </style>
            <link rel="stylesheet" href="\(urls.katexCSS.absoluteString)">
            \(highlightLinkHTML)
            \(highlightScriptsHTML)
            <script src="\(urls.markdownItScript.absoluteString)"></script>
            <script src="\(urls.katexScript.absoluteString)"></script>
            <script src="\(urls.autoRenderScript.absoluteString)"></script>
            <script src="\(urls.rendererScript.absoluteString)"></script>
          </head>
          <body>
            <pre id="md-source" style="display:none">\(escaped)</pre>
            <div id="content"></div>
          </body>
        </html>
        """

        uiView.loadHTMLString(html, baseURL: urls.baseURL)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(height: $height)
    }

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate {
        var height: Binding<CGFloat>
        var lastSignature: String?

        init(height: Binding<CGFloat>) {
            self.height = height
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            updateHeight(webView)
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping @MainActor @Sendable (WKNavigationActionPolicy) -> Void
        ) {
            if navigationAction.navigationType == .linkActivated {
                decisionHandler(.cancel)
                return
            }
            if let url = navigationAction.request.url,
               let scheme = url.scheme?.lowercased(),
               scheme == "http" || scheme == "https" {
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        private func updateHeight(_ webView: WKWebView) {
            webView.evaluateJavaScript("Math.max(document.body.scrollHeight, document.documentElement.scrollHeight)") { [weak self] result, _ in
                guard let self else { return }
                if let number = result as? Double {
                    let next = CGFloat(number)
                    if abs(self.height.wrappedValue - next) > 1 {
                        self.height.wrappedValue = next
                    }
                }
            }
        }
    }

    private struct AssetURLs: Sendable {
        var baseURL: URL
        var markdownItScript: URL
        var rendererScript: URL
        var katexScript: URL
        var katexCSS: URL
        var autoRenderScript: URL
        var highlightScript: URL?
        var highlightPythonScript: URL?
        var highlightRScript: URL?
        var highlightLightCSS: URL?
        var highlightDarkCSS: URL?
    }

    private static var resourceBundle: Bundle {
#if SWIFT_PACKAGE
        return Bundle.module
#else
        return Bundle.main
#endif
    }

    private static func assetURLs(bundle: Bundle) -> AssetURLs? {
        func firstURL(_ name: String, _ ext: String, _ subdirs: [String?]) -> URL? {
            for sub in subdirs {
                if let url = bundle.url(forResource: name, withExtension: ext, subdirectory: sub) {
                    return url
                }
            }
            return nil
        }

        let markdownSubdirs: [String?] = ["Resources/markdown", "markdown", "Resources", nil]
        let katexSubdirs: [String?] = ["Resources/katex", "katex", "Resources", nil]
        let highlightSubdirs: [String?] = ["Resources/highlightjs", "highlightjs", "Resources", nil]

        guard let markdownIt = firstURL("markdown-it.min", "js", markdownSubdirs),
              let renderer = firstURL("markdown-math-renderer", "js", markdownSubdirs),
              let katexJS = firstURL("katex.min", "js", katexSubdirs),
              let katexCSS = firstURL("katex.min", "css", katexSubdirs),
              let autoRender = firstURL("auto-render.min", "js", katexSubdirs)
        else {
            return nil
        }

        let highlight = firstURL("highlight.min", "js", highlightSubdirs)
        let python = firstURL("python.min", "js", ["Resources/highlightjs/languages", "highlightjs/languages", "Resources", nil])
        let r = firstURL("r.min", "js", ["Resources/highlightjs/languages", "highlightjs/languages", "Resources", nil])
        let cssLight = firstURL("github.min", "css", ["Resources/highlightjs/styles", "highlightjs/styles", "Resources", nil])
        let cssDark = firstURL("github-dark.min", "css", ["Resources/highlightjs/styles", "highlightjs/styles", "Resources", nil])

        return AssetURLs(
            baseURL: bundle.bundleURL,
            markdownItScript: markdownIt,
            rendererScript: renderer,
            katexScript: katexJS,
            katexCSS: katexCSS,
            autoRenderScript: autoRender,
            highlightScript: highlight,
            highlightPythonScript: python,
            highlightRScript: r,
            highlightLightCSS: cssLight,
            highlightDarkCSS: cssDark
        )
    }

    private static func escapeHTML(_ input: String) -> String {
        var s = input
        s = s.replacingOccurrences(of: "&", with: "&amp;")
        s = s.replacingOccurrences(of: "<", with: "&lt;")
        s = s.replacingOccurrences(of: ">", with: "&gt;")
        s = s.replacingOccurrences(of: "\"", with: "&quot;")
        s = s.replacingOccurrences(of: "'", with: "&#39;")
        return s
    }
}
#endif
