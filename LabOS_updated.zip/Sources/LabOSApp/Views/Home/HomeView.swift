#if os(iOS)
import LabOSCore
import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var store: AppStore
    @State private var showingSettings = false
    @State private var runningTaskIndex = 0

    private let runningTasksTimer = Timer.publish(every: 2, on: .main, in: .common).autoconnect()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                header
                runningTasksCard
                resourceCard
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 24)
        }
        .safeAreaInset(edge: .top) {
            HStack {
                Button {
                    store.openLeftPanel()
                } label: {
                    Image(systemName: "sidebar.left")
                        .font(.headline)
                        .padding(8)
                }

                Spacer()

                Text("Home")
                    .font(.headline)

                Spacer()

                Button {
                    showingSettings = true
                } label: {
                    Image(systemName: "gearshape")
                        .font(.headline)
                        .padding(8)
                }
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 10)
            .background(.ultraThinMaterial)
        }
        .sheet(isPresented: $showingSettings) {
            HomeSettingsSheet()
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(greeting)
                .font(.title2.weight(.semibold))
        }
    }

    private var runningTasksCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Running Tasks")
                    .font(.headline)
                Spacer()
                Text("\(store.homeTasks.count)")
                    .font(.caption.weight(.semibold))
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .background(Capsule().fill(Color.blue.opacity(0.16)))
            }

            if store.homeTasks.isEmpty {
                Text("No tasks running.")
                    .foregroundStyle(.secondary)
            } else {
                TabView(selection: $runningTaskIndex) {
                    ForEach(Array(store.homeTasks.enumerated()), id: \.element.id) { index, row in
                        runningTaskSlide(row)
                            .tag(index)
                    }
                }
                .frame(height: 108)
                .tabViewStyle(.page(indexDisplayMode: store.homeTasks.count > 1 ? .automatic : .never))
                .onReceive(runningTasksTimer) { _ in
                    guard store.homeTasks.count > 1 else { return }
                    withAnimation(.easeInOut(duration: 0.35)) {
                        runningTaskIndex = (runningTaskIndex + 1) % store.homeTasks.count
                    }
                }
                .onChange(of: store.homeTasks.count) { _, newCount in
                    guard newCount > 0 else {
                        runningTaskIndex = 0
                        return
                    }
                    runningTaskIndex = min(runningTaskIndex, newCount - 1)
                }
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemBackground)))
    }

    private func runningTaskSlide(_ row: HomeTaskRow) -> some View {
        Button {
            store.openRun(projectID: row.projectID, runID: row.runID)
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Text(row.projectName)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text(row.status.rawValue.capitalized)
                        .font(.caption.weight(.semibold))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Capsule().fill(row.status == .running ? Color.blue.opacity(0.18) : Color.orange.opacity(0.18)))
                }

                VStack(alignment: .leading, spacing: 2) {
                    Text("Current Step")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.secondary)
                    Text(row.title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.primary)
                        .lineLimit(2)
                }

                HStack {
                    Text(row.progressText)
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Button {
                        store.openRun(projectID: row.projectID, runID: row.runID)
                    } label: {
                        Label("Open", systemImage: "chevron.right")
                            .font(.caption2.weight(.semibold))
                    }
                }
            }
        }
        .buttonStyle(.plain)
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color(.tertiarySystemBackground)))
    }

    private var resourceCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Compute Resource Monitor")
                .font(.headline)

            HStack {
                metricBlock(value: store.resourceStatus.computeConnected ? "Connected" : "Disconnected", label: "Compute")
                Spacer()
                metricBlock(value: "\(store.resourceStatus.queueDepth)", label: "Queue depth")
            }

            HStack {
                metricBlock(value: "\(Int(store.resourceStatus.storageUsedPercent))%", label: "Storage")
                Spacer()
                metricBlock(value: "CPU \(Int(store.resourceStatus.cpuPercent))% / RAM \(Int(store.resourceStatus.ramPercent))%", label: "Usage")
            }
        }
        .padding(14)
        .background(RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color(.secondarySystemBackground)))
    }

    private func metricBlock(value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(value)
                .font(.subheadline.weight(.semibold))
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: .now)
        if hour < 12 { return "Good morning" }
        if hour < 18 { return "Good afternoon" }
        return "Welcome back"
    }
}

private struct HomeSettingsSheet: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var store: AppStore

    @State private var wsURLString = ""
    @State private var token = ""
    @State private var hpcPartition = ""
    @State private var hpcAccount = ""
    @State private var hpcQos = ""
    @State private var saveToastText: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Account") {
                    LabeledContent("Signed in as", value: "Local User")
                    LabeledContent("Plan", value: "LabOS v0.1")
                }

                Section("Gateway") {
                    TextField("ws://host:8787/ws", text: $wsURLString)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("Shared token", text: $token)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    LabeledContent("Status", value: gatewayStatusText)

                    Button("Save") {
                        store.saveGatewaySettings(wsURLString: wsURLString, token: token)
                        wsURLString = store.gatewayWSURLString
                        token = store.gatewayToken
                        showToast("Gateway saved")
                    }

                    if store.isGatewayConnected {
                        Button("Disconnect", role: .destructive) {
                            store.disconnectGateway()
                        }
                    } else {
                        Button("Connect") {
                            store.saveGatewaySettings(wsURLString: wsURLString, token: token)
                            wsURLString = store.gatewayWSURLString
                            token = store.gatewayToken
                            Task { await store.connectGateway() }
                        }
                        .disabled(wsURLString.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || token.isEmpty)
                    }
                }

                Section("HPC") {
                    TextField("Partition", text: $hpcPartition)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    TextField("Account", text: $hpcAccount)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    TextField("QoS", text: $hpcQos)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    Button("Save") {
                        store.saveHpcSettings(partition: hpcPartition, account: hpcAccount, qos: hpcQos)
                        hpcPartition = store.hpcPartition
                        hpcAccount = store.hpcAccount
                        hpcQos = store.hpcQos
                        store.pushHpcPreferencesToGateway()
                        showToast(store.isGatewayConnected ? "HPC saved and pushed" : "HPC saved")
                    }

                    if let hpc = store.resourceStatus.hpc {
                        LabeledContent("Scope", value: hpcScopeText(hpc))
                        LabeledContent("Jobs", value: "R \(hpc.runningJobs) / PD \(hpc.pendingJobs)")
                        LabeledContent("Quota remaining", value: formatTres(hpc.available))
                    } else {
                        LabeledContent("Status", value: store.isGatewayConnected ? "Waiting for bridge…" : "Connect gateway to view")
                    }
                }

                Section("Preferences") {
                    Label("Notifications", systemImage: "bell")
                    Label("Data & Storage", systemImage: "externaldrive")
                    Label("About LabOS", systemImage: "info.circle")
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                wsURLString = store.gatewayWSURLString
                token = store.gatewayToken
                hpcPartition = store.hpcPartition
                hpcAccount = store.hpcAccount
                hpcQos = store.hpcQos
            }
        }
        .presentationDetents([.medium, .large])
        .overlay(alignment: .bottom) {
            if let saveToastText {
                Text(saveToastText)
                    .font(.caption)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Capsule().fill(Color.black.opacity(0.8)))
                    .foregroundStyle(.white)
                    .padding(.bottom, 14)
                    .transition(.opacity)
            }
        }
    }

    private var gatewayStatusText: String {
        switch store.gatewayConnectionState {
        case .disconnected:
            return "Disconnected"
        case .connecting:
            return "Connecting…"
        case let .connected(connectionID):
            return "Connected (\(connectionID.uuidString.prefix(8)))"
        case let .failed(message):
            return "Failed: \(message)"
        }
    }

    private func hpcScopeText(_ hpc: HPCStatus) -> String {
        let p = hpc.partition?.isEmpty == false ? hpc.partition! : "—"
        let a = hpc.account?.isEmpty == false ? hpc.account! : "—"
        let q = hpc.qos?.isEmpty == false ? hpc.qos! : "—"
        return "p=\(p) a=\(a) q=\(q)"
    }

    private func formatTres(_ tres: HPCStatus.Tres?) -> String {
        guard let tres else { return "—" }
        let cpu = tres.cpu.map(String.init) ?? "—"
        let gpu = tres.gpus.map(String.init) ?? "—"
        let mem = tres.memMB.map { "\($0) MB" } ?? "—"
        return "CPU \(cpu) / GPU \(gpu) / Mem \(mem)"
    }

    private func showToast(_ text: String) {
        withAnimation(.easeOut(duration: 0.15)) {
            saveToastText = text
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) {
            guard saveToastText == text else { return }
            withAnimation(.easeOut(duration: 0.2)) {
                saveToastText = nil
            }
        }
    }
}
#endif
