#if os(iOS)
import LabOSCore
import MarkdownUI
import SwiftUI

struct MessageBubbleView: View {
    let message: ChatMessage
    let onArtifactTap: (ChatArtifactReference) -> Void

    @EnvironmentObject private var store: AppStore
    @Environment(\.colorScheme) private var colorScheme
    @State private var streamingIdleFallbackActive = false
    @State private var streamingIdleTask: Task<Void, Never>?

    var body: some View {
        switch message.role {
        case .user:
            userBubble
        case .assistant:
            assistantMessage
        case .tool, .system:
            statusMessage
        }
    }

    private var userBubble: some View {
        HStack(alignment: .bottom) {
            Spacer(minLength: 48)

            Text(message.text)
                .font(.body)
                .foregroundStyle(colorScheme == .dark ? Color.black : Color.primary)
                .padding(.horizontal, 14)
                .padding(.vertical, 10)
                .fixedSize(horizontal: false, vertical: true)
                .background(
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .fill(colorScheme == .dark ? Color.white.opacity(0.95) : Color(uiColor: .secondarySystemBackground))
                )
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 4)
    }

    private var assistantMessage: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 10) {
                assistantText
                    .font(.body)

                if let plan = message.proposedPlan {
                    planSummary(plan)
                }

                if !message.artifactRefs.isEmpty {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(Array(message.artifactRefs.enumerated()), id: \.offset) { _, ref in
                            Button {
                                onArtifactTap(ref)
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "doc")
                                    Text(ref.displayText)
                                        .lineLimit(1)
                                }
                                .font(.subheadline)
                                .foregroundStyle(.blue)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(
                                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                                        .fill(Color.blue.opacity(0.1))
                                )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            Spacer(minLength: 48)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 6)
    }

    private var statusMessage: some View {
        Group {
            if message.role == .tool {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: toolMessageIcon)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)

                    VStack(alignment: .leading, spacing: 2) {
                        Text(toolMessageHeader)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)

                        if let output = toolMessageOutput {
                            Text(output)
                                .font(.footnote)
                                .foregroundStyle(.primary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }

                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 3)
            } else {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "info.circle.fill")
                        .font(.caption)
                        .foregroundStyle(.orange)

                    Text(message.text)
                        .font(.footnote)
                        .foregroundStyle(.secondary)

                    Spacer(minLength: 0)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 8)
                .background(
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .fill(Color.orange.opacity(0.12))
                )
                .padding(.horizontal, 12)
                .padding(.vertical, 4)
            }
        }
    }

    private var toolMessageHeader: String {
        let parts = message.text.split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: false)
        guard let first = parts.first else { return message.text }
        return String(first)
    }

    private var toolMessageOutput: String? {
        let parts = message.text.split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: false)
        guard parts.count > 1 else { return nil }
        return String(parts[1]).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var toolMessageIcon: String {
        let header = toolMessageHeader.lowercased()
        if header.contains("command") { return "terminal" }
        if header.contains("tool call") { return "wrench.and.screwdriver" }
        if header.contains("output") { return "doc.badge.plus" }
        return "info.circle"
    }

    @ViewBuilder
    private var assistantText: some View {
        let isStoreStreaming = store.streamingAssistantMessageIDBySession[message.sessionID] == message.id
        let isStreaming = isStoreStreaming && !streamingIdleFallbackActive

        Group {
            if !isStreaming, MarkdownMathPreprocessor.likelyContainsMath(message.text) {
                MarkdownMathView(markdown: message.text)
            } else {
                StreamingMarkdownView(text: message.text, isStreaming: isStreaming)
            }
        }
        .onAppear { scheduleStreamingIdleFallback() }
        .onDisappear {
            streamingIdleTask?.cancel()
            streamingIdleTask = nil
        }
        .onChange(of: message.text) { _, _ in
            scheduleStreamingIdleFallback()
        }
        .onChange(of: store.streamingAssistantMessageIDBySession[message.sessionID] == message.id) { _, _ in
            scheduleStreamingIdleFallback()
        }
    }

    private func scheduleStreamingIdleFallback() {
        streamingIdleTask?.cancel()
        streamingIdleTask = nil

        let isStoreStreaming = store.streamingAssistantMessageIDBySession[message.sessionID] == message.id
        guard isStoreStreaming else {
            streamingIdleFallbackActive = false
            return
        }

        streamingIdleFallbackActive = false
        let snapshot = message.text

        streamingIdleTask = Task {
            try? await Task.sleep(nanoseconds: 1_000_000_000)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                let stillStoreStreaming = store.streamingAssistantMessageIDBySession[message.sessionID] == message.id
                if stillStoreStreaming, message.text == snapshot {
                    streamingIdleFallbackActive = true
                }
            }
        }
    }

    private func planSummary(_ plan: ExecutionPlan) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Proposed Plan")
                .font(.caption.weight(.semibold))
            ForEach(plan.steps.indices, id: \.self) { idx in
                Text("\(idx + 1). \(plan.steps[idx].title)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 10, style: .continuous)
                .fill(Color.yellow.opacity(0.14))
        )
    }
}
#endif
