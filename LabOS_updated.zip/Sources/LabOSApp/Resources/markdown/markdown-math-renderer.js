(function () {
  function safeGetText(id) {
    var el = document.getElementById(id);
    if (!el) return "";
    return el.textContent || el.innerText || "";
  }

  function render() {
    var source = safeGetText("md-source");
    var content = document.getElementById("content");
    if (!content) return;

    if (!window.markdownit) {
      content.textContent = source;
      return;
    }

    var md = window.markdownit({
      html: false,
      linkify: true,
      typographer: false,
    });

    // Enable common GFM-ish extensions.
    try {
      md.enable(["table", "strikethrough"]);
    } catch (e) {}

    var rendered = "";
    try {
      rendered = md.render(source);
    } catch (e) {
      rendered = "<pre class=\"md-error\"></pre>";
      content.textContent = source;
      return;
    }

    var container = document.createElement("div");
    container.innerHTML = rendered;

    // Block external resources.
    var links = container.querySelectorAll("a[href]");
    for (var i = 0; i < links.length; i++) {
      var href = (links[i].getAttribute("href") || "").trim();
      if (href.startsWith("http:") || href.startsWith("https:")) {
        links[i].setAttribute("href", "#");
      }
    }
    var images = container.querySelectorAll("img[src]");
    for (var j = 0; j < images.length; j++) {
      var src = (images[j].getAttribute("src") || "").trim();
      if (src.startsWith("http:") || src.startsWith("https:")) {
        images[j].removeAttribute("src");
      }
    }

    content.innerHTML = container.innerHTML;

    // Highlight code blocks (optional).
    if (window.hljs) {
      var blocks = content.querySelectorAll("pre code");
      for (var i = 0; i < blocks.length; i++) {
        try {
          window.hljs.highlightElement(blocks[i]);
        } catch (e) {}
      }
    }

    // Render LaTeX math.
    if (window.renderMathInElement) {
      try {
        window.renderMathInElement(content, {
          delimiters: [
            { left: "$$", right: "$$", display: true },
            { left: "$", right: "$", display: false },
            { left: "\\[", right: "\\]", display: true },
            { left: "\\(", right: "\\)", display: false },
          ],
          macros: {
            // Common "missing package" macros from LLM outputs.
            "\\mathbbf": "\\mathbf",
            "\\mathbbm": "\\mathbb",
            "\\bm": "\\boldsymbol",
          },
          throwOnError: false,
          strict: "warn",
        });
      } catch (e) {}
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", render);
  } else {
    render();
  }
})();
