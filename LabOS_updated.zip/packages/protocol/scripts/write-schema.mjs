import { writeFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import path from "node:path";

import { ProtocolSchema } from "../dist/index.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const outPath = path.join(here, "..", "dist", "schema.json");

await writeFile(outPath, JSON.stringify(ProtocolSchema, null, 2) + "\n", "utf8");

