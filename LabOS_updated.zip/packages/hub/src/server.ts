import multipart from "@fastify/multipart";
import Fastify, { type FastifyInstance } from "fastify";
import { createHmac, randomBytes } from "node:crypto";
import { createReadStream, createWriteStream, existsSync } from "node:fs";
import { appendFile, mkdir, readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { pipeline } from "node:stream/promises";
import { v4 as uuidv4 } from "uuid";
import { WebSocketServer, type WebSocket } from "ws";

import {
  getEnvApiKey,
  getOAuthProvider,
  streamSimple,
  type Context as PiContext,
  type Model as PiModel,
  type SimpleStreamOptions,
  type Usage,
} from "@mariozechner/pi-ai";

import { saveHubConfig, type HubConfig } from "./config.js";
import type { DbPool } from "./db/db.js";
import { listHubModelsForProvider, resolveHubModelForRun, resolveHubProvider } from "./model.js";
import { runLabosAgentTurn } from "./agent/runtime.js";

type Role = "operator" | "node";

type HubStartOptions = {
  port: number;
  host: string;
  config: HubConfig;
  stateDir: string;
  pool: DbPool;
};

type ConnectionContext =
  | {
      role: "operator";
      connectionId: string;
      deviceId: string;
      deviceName: string;
      platform: string;
      clientName: string;
      clientVersion: string;
      scopes: string[];
    }
  | {
      role: "node";
      connectionId: string;
      deviceId: string;
      deviceName: string;
      platform: string;
      clientName: string;
      clientVersion: string;
      caps: string[];
      commands: string[];
      permissions: Record<string, unknown>;
    };

type OperatorConn = { ws: WebSocket; ctx: ConnectionContext & { role: "operator" } };
type NodeConn = { ws: WebSocket; ctx: ConnectionContext & { role: "node" } };

type PendingNodeRequest = {
  resolve: (payload: unknown) => void;
  reject: (err: Error) => void;
  timeout: NodeJS.Timeout;
};

type PendingApproval = {
  resolve: (result: { decision: "approve" | "reject"; judgmentResponses?: { answers?: Record<string, string>; freeform?: Record<string, string> } }) => void;
  timeout: NodeJS.Timeout;
};

type HpcTres = {
  cpu?: number;
  memMB?: number;
  gpus?: number;
};

type HpcStatus = {
  partition?: string;
  account?: string;
  qos?: string;
  runningJobs: number;
  pendingJobs: number;
  limit?: HpcTres;
  inUse?: HpcTres;
  available?: HpcTres;
  updatedAt: string;
};

type ResourceSnapshot = {
  computeConnected: boolean;
  queueDepth: number;
  storageUsedPercent: number;
  cpuPercent: number;
  ramPercent: number;
  hpc?: HpcStatus;
};

type HpcPrefs = {
  partition?: string;
  account?: string;
  qos?: string;
  updatedAt: string;
  setByDeviceId: string;
};

const PROTOCOL_VERSION = 1;

export type HubHandle = {
  close: () => Promise<void>;
};

export async function startHub(opts: HubStartOptions): Promise<HubHandle> {
  const fastify = Fastify({ logger: true });
  await fastify.register(multipart, {
    limits: {
      fileSize: 1024 * 1024 * 512,
    },
  });

  const state = createHubState(opts);
  await ensureHubDirs(opts.stateDir);

  if ((process.env.LABOS_REPAIR_ON_START ?? "1") !== "0") {
    await repairMessagesFromJsonl(state).catch((err) => {
      fastify.log.error({ err }, "startup repair failed");
    });
  }

  registerHttpRoutes(fastify, state);

  const wss = new WebSocketServer({ noServer: true });
  fastify.server.on("upgrade", (req, socket, head) => {
    const url = req.url ?? "";
    if (!url.startsWith("/ws")) {
      socket.destroy();
      return;
    }

    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  });

  wss.on("connection", (ws) => {
    void handleWsConnection(ws, state);
  });

  await fastify.listen({ port: opts.port, host: opts.host });
  fastify.log.info(`LabOS Hub listening on http://${opts.host}:${opts.port} (ws: /ws)`);

  const close = async () => {
    try {
      for (const op of state.operators) {
        try {
          op.ws.close();
        } catch {
          // ignore
        }
      }
      if (state.node) {
        try {
          state.node.ws.close();
        } catch {
          // ignore
        }
      }
    } catch {
      // ignore
    }

    await new Promise<void>((resolve) => {
      try {
        wss.close(() => resolve());
      } catch {
        resolve();
      }
    });

    await fastify.close();
  };

  state.onClose.push(close);

  return { close };
}

function createHubState(opts: HubStartOptions) {
  return {
    config: opts.config,
    stateDir: opts.stateDir,
    pool: opts.pool,
    operators: new Set<OperatorConn>(),
    node: null as NodeConn | null,
    hpcPrefs: null as HpcPrefs | null,
    seq: 0,
    pendingNodeRequests: new Map<string, PendingNodeRequest>(),
    pendingApprovals: new Map<string, PendingApproval>(),
    sessionLane: new Map<string, Promise<void>>(),
    oauthRefreshLocks: new Map<string, Promise<void>>(),
    resources: {
      computeConnected: false,
      queueDepth: 0,
      storageUsedPercent: 0,
      cpuPercent: 0,
      ramPercent: 0,
    } as ResourceSnapshot,
    onClose: [] as Array<() => Promise<void>>,
  };
}

type HubState = ReturnType<typeof createHubState>;

async function ensureHubDirs(stateDir: string) {
  await mkdir(stateDir, { recursive: true });
  await mkdir(path.join(stateDir, "projects"), { recursive: true });
}

function requireHttpAuth(state: HubState, req: { headers: Record<string, string | string[] | undefined> }) {
  const header = req.headers["authorization"];
  const value = Array.isArray(header) ? header[0] : header;
  if (!value) return false;
  const token = value.replace(/^Bearer\s+/i, "");
  return token === state.config.token;
}

// UUIDs are stored as TEXT in SQLite. Clients may send uppercase UUID strings
// (e.g., Swift's UUID.uuidString). Normalize IDs to lowercase at the boundary so
// lookups work reliably.
function normalizeId(value: unknown): string {
  return String(value ?? "").trim().toLowerCase();
}

function registerHttpRoutes(fastify: FastifyInstance, state: HubState) {
  fastify.get("/status/resources", async (req, reply) => {
    if (!requireHttpAuth(state, req)) return reply.code(401).send({ error: "unauthorized" });
    return reply.send(state.resources);
  });

  fastify.post("/projects/:projectId/uploads", async (req, reply) => {
    if (!requireHttpAuth(state, req)) return reply.code(401).send({ error: "unauthorized" });
    const projectId = normalizeId((req.params as any).projectId as string);

    const part = await (req as any).file();
    if (!part) return reply.code(400).send({ error: "missing file" });

    const uploadId = uuidv4();
    const originalName = sanitizeFilename(part.filename ?? "upload.bin");

    await ensureProjectDirs(state, projectId);
    const storedName = `${uploadId}__${originalName}`;
    const storedPath = path.join(projectUploadsDir(state, projectId), storedName);

    await pipeline(part.file, createWriteStream(storedPath));

    const st = await stat(storedPath);
    const contentType = part.mimetype ?? null;

    await state.pool.query(
      `INSERT INTO uploads (id, project_id, original_name, stored_path, content_type, size_bytes, created_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [uploadId, projectId, originalName, storedPath, contentType, st.size, new Date().toISOString()]
    );

    const artifactPath = `uploads/${originalName}`;
    await upsertArtifact(state, {
      projectId,
      path: artifactPath,
      origin: "user_upload",
      modifiedAt: new Date().toISOString(),
      sizeBytes: st.size,
    });

    broadcastEvent(state, "artifacts.updated", {
      projectId,
      artifact: await getArtifactByPath(state, projectId, artifactPath),
      change: "created",
    });

    return reply.send({ uploadId, path: artifactPath });
  });

  fastify.get("/projects/:projectId/uploads/:uploadId", async (req, reply) => {
    if (!requireHttpAuth(state, req)) return reply.code(401).send({ error: "unauthorized" });
    const projectId = normalizeId((req.params as any).projectId as string);
    const uploadId = normalizeId((req.params as any).uploadId as string);

    const row = await state.pool.query<{ stored_path: string; content_type: string | null }>(
      "SELECT stored_path, content_type FROM uploads WHERE id=$1 AND project_id=$2",
      [uploadId, projectId]
    );
    if (row.rows.length === 0) return reply.code(404).send({ error: "not found" });

    const storedPath = row.rows[0].stored_path;
    const contentType = row.rows[0].content_type;
    if (contentType) reply.header("content-type", contentType);
    return reply.send(createReadStream(storedPath));
  });

  fastify.get("/projects/:projectId/artifacts/content", async (req, reply) => {
    if (!requireHttpAuth(state, req)) return reply.code(401).send({ error: "unauthorized" });
    const projectId = normalizeId((req.params as any).projectId as string);
    const artifactPath = (req.query as any).path as string | undefined;
    if (!artifactPath) return reply.code(400).send({ error: "missing path" });

    const cleanPath = normalizeRelativePath(artifactPath);
    if (!cleanPath) return reply.code(400).send({ error: "invalid path" });

    const artifact = await getArtifactByPath(state, projectId, cleanPath);
    if (!artifact) return reply.code(404).send({ error: "not found" });

    if (artifact.origin === "user_upload") {
      const originalName = path.posix.basename(cleanPath);
      const uploadRow = await state.pool.query<{ stored_path: string }>(
        "SELECT stored_path FROM uploads WHERE project_id=$1 AND original_name=$2 ORDER BY created_at DESC LIMIT 1",
        [projectId, originalName]
      );
      if (uploadRow.rows.length === 0) return reply.code(404).send({ error: "not found" });
      const storedPath = uploadRow.rows[0].stored_path;
      const raw = await readFile(storedPath);
      return reply.send(raw.toString("utf8"));
    }

    const node = state.node;
    const workspaceRoot = node?.ctx.permissions?.workspaceRoot as string | undefined;
    if (node && workspaceRoot) {
      const abs = path.join(workspaceRoot, "projects", projectId, cleanPath);
      const res = await callNode(state, "fs.readRange", {
        path: abs,
        offset: 0,
        length: 1024 * 1024,
        encoding: "utf8",
      });
      const data = (res as any).data;
      return reply.send(typeof data === "string" ? data : "");
    }

    const generatedPath = path.join(projectGeneratedDir(state, projectId), cleanPath);
    try {
      const raw = await readFile(generatedPath);
      return reply.send(raw.toString("utf8"));
    } catch {
      return reply.send("Preview not available (no node connected).");
    }
  });

  fastify.get("/projects/:projectId/artifacts/raw", async (req, reply) => {
    if (!requireHttpAuth(state, req)) return reply.code(401).send({ error: "unauthorized" });
    const projectId = normalizeId((req.params as any).projectId as string);
    const artifactPath = (req.query as any).path as string | undefined;
    if (!artifactPath) return reply.code(400).send({ error: "missing path" });

    const cleanPath = normalizeRelativePath(artifactPath);
    if (!cleanPath) return reply.code(400).send({ error: "invalid path" });

    const artifact = await getArtifactByPath(state, projectId, cleanPath);
    if (!artifact) return reply.code(404).send({ error: "not found" });

    const ext = path.posix.extname(cleanPath).toLowerCase();
    const contentType = (() => {
      switch (ext) {
        case ".png":
          return "image/png";
        case ".jpg":
        case ".jpeg":
          return "image/jpeg";
        case ".gif":
          return "image/gif";
        case ".svg":
          return "image/svg+xml";
        default:
          return "application/octet-stream";
      }
    })();

    reply.header("content-type", contentType);
    reply.header("cache-control", "private, max-age=60");

    if (artifact.origin === "user_upload") {
      const originalName = path.posix.basename(cleanPath);
      const uploadRow = await state.pool.query<{ stored_path: string }>(
        "SELECT stored_path FROM uploads WHERE project_id=$1 AND original_name=$2 ORDER BY created_at DESC LIMIT 1",
        [projectId, originalName]
      );
      if (uploadRow.rows.length === 0) return reply.code(404).send({ error: "not found" });
      const storedPath = uploadRow.rows[0].stored_path;
      return reply.send(createReadStream(storedPath));
    }

    const MAX_BYTES = 10 * 1024 * 1024;
    const node = state.node;
    const workspaceRoot = node?.ctx.permissions?.workspaceRoot as string | undefined;
    if (node && workspaceRoot) {
      const abs = path.join(workspaceRoot, "projects", projectId, cleanPath);
      const chunks: Buffer[] = [];
      let offset = 0;
      let total = 0;
      const CHUNK = 256 * 1024;

      while (true) {
        const res = await callNode(state, "fs.readRange", {
          path: abs,
          offset,
          length: CHUNK,
          encoding: "base64",
        });

        const data = (res as any).data;
        const eof = Boolean((res as any).eof);
        if (typeof data !== "string") break;

        const buf = Buffer.from(data, "base64");
        if (buf.length === 0) break;

        if (total + buf.length > MAX_BYTES) {
          return reply.code(413).send({ error: "file too large to preview" });
        }

        chunks.push(buf);
        total += buf.length;
        offset += buf.length;
        if (eof) break;
      }

      return reply.send(Buffer.concat(chunks));
    }

    const generatedPath = path.join(projectGeneratedDir(state, projectId), cleanPath);
    try {
      const st = await stat(generatedPath);
      if (st.size > MAX_BYTES) return reply.code(413).send({ error: "file too large to preview" });
      return reply.send(createReadStream(generatedPath));
    } catch {
      return reply.code(404).send({ error: "not found" });
    }
  });
}

async function handleWsConnection(ws: WebSocket, state: HubState) {
  const nonce = randomBytes(32).toString("base64url");
  const issuedAt = new Date().toISOString();
  const serverId = state.config.serverId;

  sendEvent(ws, state, "connect.challenge", {
    nonce,
    issuedAt,
    serverId,
    protocol: { min: PROTOCOL_VERSION, max: PROTOCOL_VERSION },
    hmac: { alg: "HMAC-SHA256" },
  });

  let ctx: ConnectionContext | null = null;
  const connectTimer = setTimeout(() => {
    if (!ctx) {
      ws.close(4401, "connect timeout");
    }
  }, 5_000);

  ws.on("message", (data) => {
    void (async () => {
      const text = data.toString();
      let msg: any;
      try {
        msg = JSON.parse(text);
      } catch {
        ws.close(4400, "bad json");
        return;
      }

      if (!ctx) {
        const isConnect = msg?.type === "req" && msg?.method === "connect";
        if (!isConnect) {
          sendResError(ws, msg?.id ?? "unknown", "BAD_REQUEST", "First request must be connect");
          ws.close(4400, "connect required");
          return;
        }

        const params = msg?.params ?? {};
        const token = params?.auth?.token;
        const signature = params?.auth?.signature;
        const role = params?.role as Role | undefined;
        if (typeof token !== "string" || typeof signature !== "string" || (role !== "operator" && role !== "node")) {
          sendResError(ws, msg.id, "BAD_REQUEST", "Invalid connect params");
          ws.close(4400, "bad connect");
          return;
        }
        if (token !== state.config.token) {
          sendResError(ws, msg.id, "AUTH_FAILED", "Invalid token");
          ws.close(4403, "auth failed");
          return;
        }

        const expected = createHmac("sha256", token).update(nonce).digest("base64url");
        if (signature !== expected) {
          sendResError(ws, msg.id, "AUTH_FAILED", "Invalid signature");
          ws.close(4403, "auth failed");
          return;
        }

        const minProtocol = Number(params?.minProtocol);
        const maxProtocol = Number(params?.maxProtocol);
        if (!(minProtocol <= PROTOCOL_VERSION && PROTOCOL_VERSION <= maxProtocol)) {
          sendResError(ws, msg.id, "BAD_REQUEST", "Unsupported protocol range");
          ws.close(4400, "bad protocol");
          return;
        }

        const connectionId = uuidv4();
        const device = params?.device ?? {};
        const client = params?.client ?? {};
        const deviceId = typeof device?.id === "string" ? device.id : uuidv4();
        const deviceName = typeof device?.name === "string" ? device.name : "unknown";
        const platform = typeof device?.platform === "string" ? device.platform : "unknown";
        const clientName = typeof client?.name === "string" ? client.name : "unknown";
        const clientVersion = typeof client?.version === "string" ? client.version : "unknown";

        if (role === "operator") {
          ctx = {
            role,
            connectionId,
            deviceId,
            deviceName,
            platform,
            clientName,
            clientVersion,
            scopes: Array.isArray(params?.scopes) ? params.scopes : [],
          };
          state.operators.add({ ws, ctx });
        } else {
          const nodeCtx: ConnectionContext & { role: "node" } = {
            role,
            connectionId,
            deviceId,
            deviceName,
            platform,
            clientName,
            clientVersion,
            caps: Array.isArray(params?.caps) ? params.caps : [],
            commands: Array.isArray(params?.commands) ? params.commands : [],
            permissions: typeof params?.permissions === "object" && params.permissions ? params.permissions : {},
          };
          ctx = nodeCtx;
          state.node = { ws, ctx: nodeCtx };
          state.resources.computeConnected = true;

          if (state.hpcPrefs) {
            void callNode(state, "hpc.prefs.set", {
              partition: state.hpcPrefs.partition ?? null,
              account: state.hpcPrefs.account ?? null,
              qos: state.hpcPrefs.qos ?? null,
            }).catch(() => {
              // ignore; node may not support the method yet
            });
          }
        }

        clearTimeout(connectTimer);
        sendResOk(ws, msg.id, {
          protocol: PROTOCOL_VERSION,
          connectionId,
          roleAccepted: role,
          scopesAccepted: role === "operator" ? (ctx as any).scopes : undefined,
          commandsAccepted: role === "node" ? (ctx as any).commands : undefined,
          server: { name: "@labos/hub", version: "0.1.0" },
        });
        return;
      }

      // Connected: handle frames
      if (ctx.role === "operator") {
        if (msg?.type !== "req") {
          return;
        }
        await handleOperatorRequest(state, ws, ctx, msg);
        return;
      }

      // Node connection
      if (msg?.type === "res") {
        const pending = state.pendingNodeRequests.get(msg.id);
        if (!pending) return;
        clearTimeout(pending.timeout);
        state.pendingNodeRequests.delete(msg.id);
        if (msg.ok) pending.resolve(msg.payload ?? {});
        else pending.reject(new Error(msg?.error?.message ?? "node request failed"));
        return;
      }

      if (msg?.type === "event") {
        await handleNodeEvent(state, msg.event, msg.payload ?? {});
        return;
      }
    })();
  });

  ws.on("close", () => {
    clearTimeout(connectTimer);
    if (!ctx) return;
    if (ctx.role === "operator") {
      for (const conn of state.operators) {
        if (conn.ws === ws) {
          state.operators.delete(conn);
          break;
        }
      }
    } else {
      if (state.node?.ws === ws) {
        state.node = null;
        state.resources.computeConnected = false;
        state.resources.queueDepth = 0;
        state.resources.hpc = undefined;
      }
    }
  });
}

async function handleOperatorRequest(state: HubState, ws: WebSocket, ctx: ConnectionContext & { role: "operator" }, msg: any) {
  const id = msg.id as string;
  const method = msg.method as string;
  const params = (msg.params ?? {}) as Record<string, any>;

  try {
    switch (method) {
      case "projects.list": {
        const projects = await listProjects(state);
        sendResOk(ws, id, { projects });
        return;
      }
      case "projects.create": {
        const name = String(params.name ?? "").trim() || "Untitled Project";
        const project = await createProject(state, name);
        sendResOk(ws, id, { project });
        broadcastEvent(state, "projects.updated", { project, change: "created" });
        return;
      }
      case "projects.rename": {
        const projectId = normalizeId(params.projectId);
        const name = String(params.name ?? "").trim();
        if (!projectId || !name) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or name");
          return;
        }
        const project = await renameProject(state, projectId, name);
        if (!project) {
          sendResError(ws, id, "NOT_FOUND", "Project not found");
          return;
        }
        sendResOk(ws, id, { project });
        broadcastEvent(state, "projects.updated", { project, change: "updated" });
        return;
      }
      case "projects.delete": {
        const projectId = normalizeId(params.projectId);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const deletedProject = await deleteProject(state, projectId);
        if (!deletedProject) {
          sendResError(ws, id, "NOT_FOUND", "Project not found");
          return;
        }
        sendResOk(ws, id, { ok: true });
        broadcastEvent(state, "projects.updated", { project: deletedProject, change: "deleted" });
        return;
      }
      case "sessions.list": {
        const projectId = normalizeId(params.projectId);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const includeArchived = Boolean(params.includeArchived ?? false);
        const sessions = await listSessions(state, projectId, { includeArchived });
        sendResOk(ws, id, { sessions });
        return;
      }
      case "sessions.create": {
        const projectId = normalizeId(params.projectId);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const titleRaw = params.title == null ? null : String(params.title);
        const session = await createSession(state, projectId, titleRaw);
        if (!session) {
          sendResError(ws, id, "NOT_FOUND", "Project not found");
          return;
        }
        sendResOk(ws, id, { session });
        broadcastEvent(state, "sessions.updated", { session, change: "created" });
        return;
      }
      case "sessions.update": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        if (!projectId || !sessionId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or sessionId");
          return;
        }
        const title = params.title == null ? undefined : String(params.title).trim();
        const lifecycle = params.lifecycle == null ? undefined : String(params.lifecycle);
        const session = await updateSession(state, projectId, sessionId, { title, lifecycle });
        if (!session) {
          sendResError(ws, id, "NOT_FOUND", "Session not found");
          return;
        }
        sendResOk(ws, id, { session });
        broadcastEvent(state, "sessions.updated", { session, change: "updated" });
        return;
      }
      case "sessions.permission.set": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        const level = normalizePermissionLevel(params.level);
        if (!projectId || !sessionId || !level) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId/sessionId or invalid level");
          return;
        }
        const ok = await setSessionPermissionLevel(state, projectId, sessionId, level, ctx.deviceId);
        if (!ok) {
          sendResError(ws, id, "NOT_FOUND", "Session not found");
          return;
        }
        sendResOk(ws, id, { ok: true, level });
        broadcastEvent(state, "sessions.permission.updated", { projectId, sessionId, level, updatedAt: new Date().toISOString() });
        return;
      }
      case "sessions.context.get": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        if (!projectId || !sessionId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or sessionId");
          return;
        }
        const stats = await getSessionContextStats(state, projectId, sessionId);
        if (!stats) {
          sendResError(ws, id, "NOT_FOUND", "Session not found");
          return;
        }
        sendResOk(ws, id, { context: stats });
        return;
      }
      case "sessions.delete": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        if (!projectId || !sessionId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or sessionId");
          return;
        }
        const deletedSession = await deleteSession(state, projectId, sessionId);
        if (!deletedSession) {
          sendResError(ws, id, "NOT_FOUND", "Session not found");
          return;
        }
        sendResOk(ws, id, { ok: true });
        broadcastEvent(state, "sessions.updated", { session: deletedSession, change: "deleted" });
        return;
      }
      case "models.current": {
        const resolved = resolveHubProvider(state.config);
        const provider = resolved.provider;
        const models = listHubModelsForProvider(provider);
        let defaultModelId = resolved.defaultModelId;
        if (defaultModelId && !models.some((m) => m.id === defaultModelId)) {
          defaultModelId = null;
        }
        if (!defaultModelId) {
          defaultModelId = models[0]?.id ?? "";
        }
        sendResOk(ws, id, {
          provider,
          defaultModelId,
          models,
          thinkingLevels: ["minimal", "low", "medium", "high", "xhigh"],
        });
        return;
      }
      case "hpc.prefs.set": {
        const partition = normalizeOptionalString(params.partition);
        const account = normalizeOptionalString(params.account);
        const qos = normalizeOptionalString(params.qos);
        state.hpcPrefs = {
          partition,
          account,
          qos,
          updatedAt: new Date().toISOString(),
          setByDeviceId: ctx.deviceId,
        };

        if (state.node) {
          void callNode(state, "hpc.prefs.set", { partition: partition ?? null, account: account ?? null, qos: qos ?? null }).catch(() => {
            // ignore; node may be offline or not support the method
          });
        }

        sendResOk(ws, id, { ok: true });
        return;
      }
      case "chat.history": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        const beforeTs = params.beforeTs == null ? null : String(params.beforeTs);
        const limit = params.limit == null ? 50 : Math.min(200, Math.max(1, Number(params.limit)));
        if (!projectId || !sessionId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or sessionId");
          return;
        }
        const messages = await listMessages(state, projectId, sessionId, { beforeTs, limit });
        sendResOk(ws, id, { messages });
        return;
      }
      case "chat.send": {
        const projectId = normalizeId(params.projectId);
        const sessionId = normalizeId(params.sessionId);
        const text = String(params.text ?? "").trim();
        const planMode = Boolean(params.planMode ?? false);
        const modelId = params.modelId == null ? null : String(params.modelId).trim();
        const thinkingLevel = params.thinkingLevel == null ? null : String(params.thinkingLevel).trim();
        const permissionLevel = normalizePermissionLevel(params.permissionLevel) ?? null;
        if (!projectId || !sessionId || !text) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId, sessionId, or text");
          return;
        }
        if (thinkingLevel && !["minimal", "low", "medium", "high", "xhigh"].includes(thinkingLevel)) {
          sendResError(ws, id, "BAD_REQUEST", "Invalid thinkingLevel");
          return;
        }
        if (modelId) {
          const resolved = resolveHubModelForRun(state.config, { modelIdOverride: modelId });
          if (!resolved.ok) {
            sendResError(ws, id, "BAD_REQUEST", resolved.message);
            return;
          }
        }
        if (permissionLevel) {
          void setSessionPermissionLevel(state, projectId, sessionId, permissionLevel, ctx.deviceId).catch(() => {
            // ignore; permission is best-effort
          });
        }
        const agentRunId = uuidv4();
        const acceptedAt = new Date().toISOString();
        const ok = await persistUserMessage(state, projectId, sessionId, text);
        if (!ok) {
          sendResError(ws, id, "NOT_FOUND", "Session not found");
          return;
        }

        sendResOk(ws, id, { agentRunId, acceptedAt });
        enqueueSessionRun(state, { projectId, sessionId, agentRunId, userText: text, planMode, modelId, thinkingLevel, permissionLevel });
        return;
      }
      case "exec.approval.resolve": {
        const planId = normalizeId(params.planId);
        const decision = String(params.decision ?? "");
        const judgmentResponsesRaw = params.judgmentResponses;
        if (!planId || (decision !== "approve" && decision !== "reject")) {
          sendResError(ws, id, "BAD_REQUEST", "Missing planId or invalid decision");
          return;
        }
        const judgmentResponses =
          judgmentResponsesRaw && typeof judgmentResponsesRaw === "object"
            ? {
                answers:
                  typeof (judgmentResponsesRaw as any).answers === "object" && (judgmentResponsesRaw as any).answers
                    ? (judgmentResponsesRaw as any).answers
                    : undefined,
                freeform:
                  typeof (judgmentResponsesRaw as any).freeform === "object" && (judgmentResponsesRaw as any).freeform
                    ? (judgmentResponsesRaw as any).freeform
                    : undefined,
              }
            : undefined;
        const resolved = await resolveApproval(state, planId, decision, ctx.deviceId, judgmentResponses);
        if (!resolved) {
          sendResError(ws, id, "NOT_FOUND", "Approval not found");
          return;
        }
        sendResOk(ws, id, { ok: true });
        return;
      }
      case "runs.list": {
        const projectId = normalizeId(params.projectId);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const runs = await listRuns(state, projectId);
        sendResOk(ws, id, { runs });
        return;
      }
      case "runs.get": {
        const projectId = normalizeId(params.projectId);
        const runId = normalizeId(params.runId);
        if (!projectId || !runId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or runId");
          return;
        }
        const run = await getRun(state, projectId, runId);
        if (!run) {
          sendResError(ws, id, "NOT_FOUND", "Run not found");
          return;
        }
        sendResOk(ws, id, { run });
        return;
      }
      case "artifacts.list": {
        const projectId = normalizeId(params.projectId);
        const prefix = params.prefix == null ? null : String(params.prefix);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const artifacts = await listArtifacts(state, projectId, { prefix });
        sendResOk(ws, id, { artifacts });
        return;
      }
      case "artifacts.get": {
        const projectId = normalizeId(params.projectId);
        const artifactPath = String(params.path ?? "");
        if (!projectId || !artifactPath) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or path");
          return;
        }
        const artifact = await getArtifactByPath(state, projectId, artifactPath);
        if (!artifact) {
          sendResError(ws, id, "NOT_FOUND", "Artifact not found");
          return;
        }
        sendResOk(ws, id, { artifact });
        return;
      }
      case "workspace.bootstrap.get": {
        const projectId = normalizeId(params.projectId);
        if (!projectId) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId");
          return;
        }
        const files = await getBootstrapFiles(state, projectId);
        sendResOk(ws, id, { files });
        return;
      }
      case "workspace.bootstrap.update": {
        const projectId = normalizeId(params.projectId);
        const name = String(params.name ?? "");
        const content = String(params.content ?? "");
        if (!projectId || !name) {
          sendResError(ws, id, "BAD_REQUEST", "Missing projectId or name");
          return;
        }
        const ok = await updateBootstrapFile(state, projectId, name, content);
        if (!ok) {
          sendResError(ws, id, "NOT_FOUND", "Project not found");
          return;
        }
        sendResOk(ws, id, { ok: true });
        return;
      }
      default:
        sendResError(ws, id, "BAD_REQUEST", `Unknown method: ${method}`);
        return;
    }
  } catch (err: any) {
    sendResError(ws, id, "INTERNAL", err?.message ?? "internal error");
  }
}

function sendResOk(ws: WebSocket, id: string, payload: any) {
  ws.send(JSON.stringify({ type: "res", id, ok: true, payload }));
}

function sendResError(ws: WebSocket, id: string, code: string, message: string, data?: any) {
  ws.send(JSON.stringify({ type: "res", id, ok: false, error: { code, message, data } }));
}

function sendEvent(ws: WebSocket, state: HubState, event: string, payload: any) {
  const seq = state.seq++;
  ws.send(JSON.stringify({ type: "event", event, payload, seq, ts: new Date().toISOString() }));
}

function broadcastEvent(state: HubState, event: string, payload: any) {
  for (const conn of state.operators) {
    sendEvent(conn.ws, state, event, payload);
  }
}

async function listProjects(state: HubState) {
  const res = await state.pool.query("SELECT id, name, created_at, updated_at FROM projects ORDER BY updated_at DESC");
  return res.rows.map((r: any) => ({
    id: r.id,
    name: r.name,
    createdAt: toIso(r.created_at),
    updatedAt: toIso(r.updated_at),
  }));
}

async function createProject(state: HubState, name: string) {
  const id = uuidv4();
  const now = new Date().toISOString();
  await state.pool.query("INSERT INTO projects (id, name, created_at, updated_at) VALUES ($1,$2,$3,$4)", [id, name, now, now]);
  await ensureProjectDirs(state, id);
  await ensureBootstrapDefaults(state, id);
  return { id, name, createdAt: now, updatedAt: now };
}

async function renameProject(state: HubState, projectId: string, name: string) {
  const now = new Date().toISOString();
  const res = await state.pool.query(
    "UPDATE projects SET name=$1, updated_at=$2 WHERE id=$3 RETURNING id, name, created_at, updated_at",
    [name, now, projectId]
  );
  if (res.rows.length === 0) return null;
  const r: any = res.rows[0];
  return { id: r.id, name: r.name, createdAt: toIso(r.created_at), updatedAt: toIso(r.updated_at) };
}

async function deleteProject(state: HubState, projectId: string) {
  const existing = await state.pool.query("SELECT id, name, created_at, updated_at FROM projects WHERE id=$1", [projectId]);
  if (existing.rows.length === 0) return null;
  const row: any = existing.rows[0];

  const res = await state.pool.query("DELETE FROM projects WHERE id=$1", [projectId]);
  if (res.rowCount === 0) return null;
  await rm(projectDir(state, projectId), { recursive: true, force: true });
  return { id: row.id, name: row.name, createdAt: toIso(row.created_at), updatedAt: toIso(row.updated_at) };
}

async function listSessions(state: HubState, projectId: string, opts: { includeArchived: boolean }) {
  const sql = opts.includeArchived
    ? "SELECT * FROM sessions WHERE project_id=$1 ORDER BY updated_at DESC"
    : "SELECT * FROM sessions WHERE project_id=$1 AND lifecycle='active' ORDER BY updated_at DESC";
  const res = await state.pool.query(sql, [projectId]);
  return res.rows.map((r: any) => ({
    id: r.id,
    projectID: r.project_id,
    title: r.title,
    lifecycle: r.lifecycle,
    createdAt: toIso(r.created_at),
    updatedAt: toIso(r.updated_at),
  }));
}

async function createSession(state: HubState, projectId: string, titleRaw: string | null) {
  const project = await state.pool.query("SELECT 1 FROM projects WHERE id=$1", [projectId]);
  if (project.rows.length === 0) return null;

  const countRes = await state.pool.query<{ count: string }>("SELECT COUNT(1) as count FROM sessions WHERE project_id=$1", [projectId]);
  const count = Number(countRes.rows[0]?.count ?? "0");

  const id = uuidv4();
  const title = titleRaw?.trim() ? titleRaw.trim() : `Session ${count + 1}`;
  const now = new Date().toISOString();
  await state.pool.query(
    "INSERT INTO sessions (id, project_id, title, lifecycle, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6)",
    [id, projectId, title, "active", now, now]
  );
  await ensureProjectDirs(state, projectId);
  await appendTranscriptLine(state, projectId, id, {
    type: "session.created",
    ts: now,
    sessionId: id,
  });
  // ensure transcript exists
  await mkdir(projectSessionsDir(state, projectId), { recursive: true });
  await appendFile(sessionTranscriptPath(state, projectId, id), "", "utf8");
  return { id, projectID: projectId, title, lifecycle: "active", createdAt: now, updatedAt: now };
}

async function updateSession(
  state: HubState,
  projectId: string,
  sessionId: string,
  patch: { title?: string; lifecycle?: string }
) {
  const updates: string[] = [];
  const args: any[] = [];
  let idx = 1;
  if (patch.title && patch.title.trim()) {
    updates.push(`title=$${idx++}`);
    args.push(patch.title.trim());
  }
  if (patch.lifecycle === "active" || patch.lifecycle === "archived") {
    updates.push(`lifecycle=$${idx++}`);
    args.push(patch.lifecycle);
  }
  updates.push(`updated_at=$${idx++}`);
  args.push(new Date().toISOString());
  args.push(projectId);
  args.push(sessionId);

  const res = await state.pool.query(
    `UPDATE sessions SET ${updates.join(", ")} WHERE project_id=$${idx++} AND id=$${idx} RETURNING *`,
    args
  );
  if (res.rows.length === 0) return null;
  const r: any = res.rows[0];
  return { id: r.id, projectID: r.project_id, title: r.title, lifecycle: r.lifecycle, createdAt: toIso(r.created_at), updatedAt: toIso(r.updated_at) };
}

async function setSessionPermissionLevel(
  state: HubState,
  projectId: string,
  sessionId: string,
  level: "default" | "full",
  _deviceId: string
) {
  const res = await state.pool.query("UPDATE sessions SET permission_level=$1 WHERE project_id=$2 AND id=$3", [level, projectId, sessionId]);
  return res.rowCount > 0;
}

async function getSessionPermissionLevel(state: HubState, projectId: string, sessionId: string): Promise<"default" | "full"> {
  const res = await state.pool.query<any>("SELECT permission_level FROM sessions WHERE project_id=$1 AND id=$2", [projectId, sessionId]);
  const raw = res.rows[0]?.permission_level;
  return normalizePermissionLevel(raw) ?? "default";
}

async function getSessionContextStats(state: HubState, projectId: string, sessionId: string) {
  const res = await state.pool.query<any>(
    `SELECT permission_level, context_model_id, context_window_tokens, context_used_input_tokens, context_used_tokens, context_updated_at
     FROM sessions WHERE project_id=$1 AND id=$2`,
    [projectId, sessionId]
  );
  const row: any = res.rows[0];
  if (!row) return null;
  const contextWindowTokens = row.context_window_tokens == null ? null : Number(row.context_window_tokens);
  const usedInputTokens = row.context_used_input_tokens == null ? null : Number(row.context_used_input_tokens);
  const usedTokens = row.context_used_tokens == null ? null : Number(row.context_used_tokens);
  return {
    projectId,
    sessionId,
    permissionLevel: typeof row.permission_level === "string" ? row.permission_level : "default",
    modelId: row.context_model_id == null ? null : String(row.context_model_id),
    contextWindowTokens,
    usedInputTokens,
    usedTokens,
    remainingTokens:
      typeof contextWindowTokens === "number" && typeof usedInputTokens === "number"
        ? Math.max(0, Math.max(1, Math.floor(contextWindowTokens)) - Math.max(0, Math.floor(usedInputTokens)))
        : typeof contextWindowTokens === "number" && typeof usedTokens === "number"
          ? Math.max(0, Math.max(1, Math.floor(contextWindowTokens)) - Math.max(0, Math.floor(usedTokens)))
        : null,
    updatedAt: row.context_updated_at == null ? null : String(row.context_updated_at),
  };
}

async function persistSessionContextStats(state: HubState, stats: {
  projectId: string;
  sessionId: string;
  modelId: string;
  contextWindowTokens: number;
  usedInputTokens: number;
  usedTokens: number;
}) {
  const now = new Date().toISOString();
  const contextWindowTokens = Math.max(1, Math.floor(stats.contextWindowTokens));
  const usedInputTokens = Math.max(0, Math.floor(stats.usedInputTokens));
  const usedTokens = Math.max(0, Math.floor(stats.usedTokens));

  await state.pool.query(
    `UPDATE sessions SET
       context_model_id=$1,
       context_window_tokens=$2,
       context_used_input_tokens=$3,
       context_used_tokens=$4,
       context_updated_at=$5
     WHERE project_id=$6 AND id=$7`,
    [
      stats.modelId,
      contextWindowTokens,
      usedInputTokens,
      usedTokens,
      now,
      stats.projectId,
      stats.sessionId,
    ]
  );

  broadcastEvent(state, "sessions.context.updated", {
    projectId: stats.projectId,
    sessionId: stats.sessionId,
    modelId: stats.modelId,
    contextWindowTokens,
    usedInputTokens,
    usedTokens,
    remainingTokens: Math.max(0, contextWindowTokens - usedInputTokens),
    updatedAt: now,
  });
}

async function deleteSession(state: HubState, projectId: string, sessionId: string) {
  const existing = await state.pool.query("SELECT * FROM sessions WHERE project_id=$1 AND id=$2", [projectId, sessionId]);
  if (existing.rows.length === 0) return null;
  const r: any = existing.rows[0];
  const deletedSession = {
    id: r.id,
    projectID: r.project_id,
    title: r.title,
    lifecycle: r.lifecycle,
    createdAt: toIso(r.created_at),
    updatedAt: toIso(r.updated_at),
  };

  // detach runs from deleted session
  await state.pool.query("UPDATE runs SET session_id=NULL WHERE project_id=$1 AND session_id=$2", [projectId, sessionId]);

  const res = await state.pool.query("DELETE FROM sessions WHERE project_id=$1 AND id=$2", [projectId, sessionId]);
  if (res.rowCount === 0) return null;
  await rm(sessionTranscriptPath(state, projectId, sessionId), { force: true });
  return deletedSession;
}

async function listMessages(state: HubState, projectId: string, sessionId: string, opts: { beforeTs: string | null; limit: number }) {
  const args: any[] = [projectId, sessionId];
  let where = "project_id=$1 AND session_id=$2";
  if (opts.beforeTs) {
    args.push(opts.beforeTs);
    where += ` AND ts < $${args.length}`;
  }
  args.push(opts.limit);
  const sql = `SELECT * FROM messages WHERE ${where} ORDER BY ts DESC LIMIT $${args.length}`;
  const res = await state.pool.query(sql, args);
  const rows = res.rows.reverse();
  return rows.map((r: any) => ({
    id: r.id,
    sessionID: r.session_id,
    role: r.role,
    text: r.content,
    createdAt: toIso(r.ts),
    artifactRefs: parseJson(r.artifact_refs, []),
    proposedPlan: parseJson(r.proposed_plan, null),
    runID: r.run_id ?? null,
    parentID: r.parent_id ?? null,
  }));
}

async function persistUserMessage(state: HubState, projectId: string, sessionId: string, text: string) {
  const exists = await state.pool.query("SELECT 1 FROM sessions WHERE id=$1 AND project_id=$2", [sessionId, projectId]);
  if (exists.rows.length === 0) return false;

  const id = uuidv4();
  const now = new Date().toISOString();
  const message = {
    id,
    sessionID: sessionId,
    role: "user",
    text,
    createdAt: now,
    artifactRefs: [],
    proposedPlan: null,
  };

  await appendTranscriptLine(state, projectId, sessionId, {
    id,
    ts: now,
    role: "user",
    content: text,
    artifactRefs: [],
  });

  await state.pool.query(
    `INSERT INTO messages (id, project_id, session_id, ts, role, content, artifact_refs, proposed_plan)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [id, projectId, sessionId, now, "user", text, JSON.stringify([]), null]
  );

  await state.pool.query(
    "UPDATE sessions SET updated_at=$1, last_message_preview=$2, last_message_at=$1 WHERE id=$3 AND project_id=$4",
    [now, preview(text), sessionId, projectId]
  );

  broadcastEvent(state, "chat.message.created", { projectId, sessionId, message });
  return true;
}

function enqueueSessionRun(
  state: HubState,
  run: {
    projectId: string;
    sessionId: string;
    agentRunId: string;
    userText: string;
    planMode: boolean;
    modelId: string | null;
    thinkingLevel: string | null;
    permissionLevel: "default" | "full" | null;
  }
) {
  const key = run.sessionId;
  const prev = state.sessionLane.get(key) ?? Promise.resolve();
  const next = prev
    .catch(() => {})
    .then(() => executeAgentRun(state, run))
    .catch((err) => {
      // eslint-disable-next-line no-console
      console.error("run failed", err);
    });
  state.sessionLane.set(key, next);
}

async function executeAgentRun(
  state: HubState,
  run: {
    projectId: string;
    sessionId: string;
    agentRunId: string;
    userText: string;
    planMode: boolean;
    modelId: string | null;
    thinkingLevel: string | null;
    permissionLevel: "default" | "full" | null;
  }
) {
  broadcastEvent(state, "agent.stream.lifecycle", {
    agentRunId: run.agentRunId,
    projectId: run.projectId,
    sessionId: run.sessionId,
    phase: "start",
  });

  // v0.1: Build run context from workspace bootstrap + canonical transcript JSONL,
  // mirroring OpenClaw's "session memory = transcript" prompt assembly pattern.
  const context = await buildRunContext(state, run.projectId, run.sessionId, { historyLimit: 200 });
  const userMsgCount = context.transcript.filter((m) => m.role === "user").length;
  const priorUserCount = Math.max(0, userMsgCount - 1); // current user message was already appended

  const wantsPlan = run.planMode || /\b(run|analyze|download|build|execute)\b/i.test(run.userText);

  const modelResolution = resolveHubModelForRun(state.config, { modelIdOverride: run.modelId });
  if (modelResolution.ok) {
    if (!modelResolution.hasApiKey) {
      const assistantMessageId = uuidv4();
      const assistantText = `Model is configured as ${modelResolution.provider}/${modelResolution.modelId}, but no credentials are configured for provider "${modelResolution.provider}". Run: labos-hub config`;
      await streamAssistant(state, {
        agentRunId: run.agentRunId,
        projectId: run.projectId,
        sessionId: run.sessionId,
        messageId: assistantMessageId,
        text: assistantText,
      });
      await persistAssistantMessage(state, {
        projectId: run.projectId,
        sessionId: run.sessionId,
        id: assistantMessageId,
        text: assistantText,
        proposedPlan: null,
        artifactRefs: [],
      });
      broadcastEvent(state, "agent.stream.lifecycle", {
        agentRunId: run.agentRunId,
        projectId: run.projectId,
        sessionId: run.sessionId,
        phase: "end",
      });
      return;
    }

    const systemText = buildSystemPromptFromBootstrap(context.bootstrap, {
      now: new Date().toISOString(),
      provider: modelResolution.provider,
      modelId: modelResolution.modelId,
      planMode: run.planMode,
      wantsPlan,
    });

    const transcript = (() => {
      const last = context.transcript[context.transcript.length - 1];
      if (last && last.role === "user" && last.content === run.userText) {
        return context.transcript.slice(0, -1);
      }
      return context.transcript;
    })();

    const contextWindowTokens =
      typeof modelResolution.model?.contextWindow === "number" && Number.isFinite(modelResolution.model.contextWindow)
        ? Math.max(1, Math.floor(modelResolution.model.contextWindow))
        : 200_000;

    const thresholdTokens = Math.floor(contextWindowTokens * 0.9);

    const apiKey = await getApiKeyForProvider(state, modelResolution.provider);

    let finalTranscript = transcript;
    let estimatedInputTokens = estimateInputTokensForRun({
      systemPrompt: systemText,
      transcript: finalTranscript,
      userText: run.userText,
    });

    if (estimatedInputTokens >= thresholdTokens && apiKey) {
      const compacted = await compactSessionTranscript(state, {
        projectId: run.projectId,
        sessionId: run.sessionId,
        model: modelResolution.model,
        apiKey,
        contextWindowTokens,
        currentUserText: run.userText,
        trigger: "auto",
      });

      if (compacted) {
        const refreshed = await buildRunContext(state, run.projectId, run.sessionId, { historyLimit: 200 });
        finalTranscript = (() => {
          const last = refreshed.transcript[refreshed.transcript.length - 1];
          if (last && last.role === "user" && last.content === run.userText) {
            return refreshed.transcript.slice(0, -1);
          }
          return refreshed.transcript;
        })();
        estimatedInputTokens = estimateInputTokensForRun({
          systemPrompt: systemText,
          transcript: finalTranscript,
          userText: run.userText,
        });
      }
    }

    await persistSessionContextStats(state, {
      projectId: run.projectId,
      sessionId: run.sessionId,
      modelId: modelResolution.model.id,
      contextWindowTokens,
      usedInputTokens: estimatedInputTokens,
      usedTokens: estimatedInputTokens,
    });

    const runTurn = async () => {
      await runLabosAgentTurn({
        host: {
          nowIso: () => new Date().toISOString(),
          broadcastEvent: (event, payload) => broadcastEvent(state, event, payload),
          getApiKey: (provider) => getApiKeyForProvider(state, provider),
          persistAssistantMessage: (msg) => persistAssistantMessage(state, msg),
          persistToolMessage: (msg) => persistToolMessage(state, msg.projectId, msg.sessionId, msg.text, msg.runId),
          insertPlan: (plan, agentRunId) => insertPlan(state, plan, agentRunId),
          waitForApproval: (planId) => waitForApproval(state, planId),
          createRunRecord: (opts) => createRunRecord(state, opts),
          executePlan: ({ projectId, sessionId, agentRunId, plan, runId }) =>
            executePlan(state, { projectId, sessionId, agentRunId, plan, runId }),
          updateRunCurrentStep: ({ projectId, runId, currentStep, logSnippet }) =>
            updateRunCurrentStep(state, { projectId, runId, currentStep, logSnippet }),
        },
        agentRunId: run.agentRunId,
        projectId: run.projectId,
        sessionId: run.sessionId,
        userText: run.userText,
        wantsPlan,
        planMode: run.planMode,
        model: modelResolution.model,
        thinkingLevel: run.thinkingLevel,
        systemPrompt: systemText,
        messages: toPiContextMessages(finalTranscript, modelResolution.model),
      });
    };

    try {
      await runTurn();
    } catch (err: any) {
      const errMsg = String(err?.message ?? err ?? "");
      if (apiKey && isLikelyContextOverflowError(errMsg)) {
        const compacted = await compactSessionTranscript(state, {
          projectId: run.projectId,
          sessionId: run.sessionId,
          model: modelResolution.model,
          apiKey,
          contextWindowTokens,
          currentUserText: run.userText,
          trigger: "overflow",
        });

        if (compacted) {
          const refreshed = await buildRunContext(state, run.projectId, run.sessionId, { historyLimit: 200 });
          finalTranscript = (() => {
            const last = refreshed.transcript[refreshed.transcript.length - 1];
            if (last && last.role === "user" && last.content === run.userText) {
              return refreshed.transcript.slice(0, -1);
            }
            return refreshed.transcript;
          })();
          estimatedInputTokens = estimateInputTokensForRun({
            systemPrompt: systemText,
            transcript: finalTranscript,
            userText: run.userText,
          });
          await persistSessionContextStats(state, {
            projectId: run.projectId,
            sessionId: run.sessionId,
            modelId: modelResolution.model.id,
            contextWindowTokens,
            usedInputTokens: estimatedInputTokens,
            usedTokens: estimatedInputTokens,
          });

          try {
            await runTurn();
            broadcastEvent(state, "agent.stream.lifecycle", {
              agentRunId: run.agentRunId,
              projectId: run.projectId,
              sessionId: run.sessionId,
              phase: "end",
            });
            return;
          } catch (err2: any) {
            const msg = `Agent error: ${err2?.message ?? "unknown error"}`;
            const messageId = uuidv4();
            await streamAssistant(state, {
              agentRunId: run.agentRunId,
              projectId: run.projectId,
              sessionId: run.sessionId,
              messageId,
              text: msg,
            });
            await persistAssistantMessage(state, {
              projectId: run.projectId,
              sessionId: run.sessionId,
              id: messageId,
              text: msg,
              proposedPlan: null,
              artifactRefs: [],
            });
            broadcastEvent(state, "agent.stream.lifecycle", {
              agentRunId: run.agentRunId,
              projectId: run.projectId,
              sessionId: run.sessionId,
              phase: "error",
              error: { code: "INTERNAL", message: msg },
            });
            return;
          }
        }
      }

      const msg = `Agent error: ${err?.message ?? "unknown error"}`;
      const messageId = uuidv4();
      await streamAssistant(state, {
        agentRunId: run.agentRunId,
        projectId: run.projectId,
        sessionId: run.sessionId,
        messageId,
        text: msg,
      });
      await persistAssistantMessage(state, {
        projectId: run.projectId,
        sessionId: run.sessionId,
        id: messageId,
        text: msg,
        proposedPlan: null,
        artifactRefs: [],
      });
      broadcastEvent(state, "agent.stream.lifecycle", {
        agentRunId: run.agentRunId,
        projectId: run.projectId,
        sessionId: run.sessionId,
        phase: "error",
        error: { code: "INTERNAL", message: msg },
      });
    }

    broadcastEvent(state, "agent.stream.lifecycle", {
      agentRunId: run.agentRunId,
      projectId: run.projectId,
      sessionId: run.sessionId,
      phase: "end",
    });
    return;
  }

  const assistantMessageId = uuidv4();
  const greeting = priorUserCount > 0 ? "Welcome back. " : "";
  const assistantText =
    greeting +
    (wantsPlan
      ? "Plan Mode requires a model configuration. Run: labos-hub config"
      : `LLM is not configured for this Hub. ${
          modelResolution.reason === "unknown_model" && modelResolution.ref ? `Model error: ${modelResolution.message}. ` : ""
        }Run: labos-hub config`);

  await streamAssistant(state, {
    agentRunId: run.agentRunId,
    projectId: run.projectId,
    sessionId: run.sessionId,
    messageId: assistantMessageId,
    text: assistantText,
  });

  await persistAssistantMessage(state, {
    projectId: run.projectId,
    sessionId: run.sessionId,
    id: assistantMessageId,
    text: assistantText,
    proposedPlan: null,
    artifactRefs: [],
  });

  broadcastEvent(state, "agent.stream.lifecycle", {
    agentRunId: run.agentRunId,
    projectId: run.projectId,
    sessionId: run.sessionId,
    phase: "end",
  });
}

async function streamAssistant(
  state: HubState,
  opts: { agentRunId: string; projectId: string; sessionId: string; messageId: string; text: string }
) {
  const chunks = chunkText(opts.text, 60);
  for (const delta of chunks) {
    broadcastEvent(state, "agent.stream.assistant_delta", {
      agentRunId: opts.agentRunId,
      projectId: opts.projectId,
      sessionId: opts.sessionId,
      messageId: opts.messageId,
      delta,
    });
    await sleep(30);
  }
}

function toPiContextMessages(transcript: Array<{ ts: string; role: string; content: string }>, model: PiModel<any>) {
  const out: any[] = [];
  for (const m of transcript) {
    const tsMs = Date.parse(m.ts);
    const timestamp = Number.isFinite(tsMs) ? tsMs : Date.now();
    if (m.role === "user") {
      out.push({ role: "user", content: m.content, timestamp });
    } else if (m.role === "assistant") {
      out.push({
        role: "assistant",
        content: [{ type: "text", text: m.content }],
        api: model.api,
        provider: model.provider,
        model: model.id,
        usage: zeroUsage(),
        stopReason: "stop",
        timestamp,
      });
    }
  }
  return out;
}

function zeroUsage(): Usage {
  return {
    input: 0,
    output: 0,
    cacheRead: 0,
    cacheWrite: 0,
    totalTokens: 0,
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 },
  };
}

function buildSystemPromptFromBootstrap(
  files: Array<{ name: string; content: string }>,
  opts: { now: string; provider: string; modelId: string; planMode: boolean; wantsPlan: boolean }
) {
  const order = ["AGENTS.md", "USERS.md", "SOUL.md", "TOOLS.md"];
  const byName = new Map(files.map((f) => [f.name, f.content] as const));
  const sections: string[] = [];
  sections.push(
    [
      "You are the LabOS agent.",
      "",
      "# Safety",
      "- Do not perform side effects (Slurm submit, filesystem writes/staging, network downloads) without operator approval.",
      "- If execution is needed, propose a plan and request approval before running anything.",
      "",
      "# Runtime",
      `- Now: ${opts.now}`,
      `- Model: ${opts.provider}/${opts.modelId}`,
      `- Plan Mode: ${opts.planMode ? "enabled" : "disabled"}`,
      "",
      "# Project Context",
    ].join("\n")
  );

  for (const name of order) {
    const content = String(byName.get(name) ?? "").trim();
    sections.push(`\n## ${name}\n${content || "(empty)"}`);
  }

  sections.push(
    [
      "",
      "# Tools",
      "- labos_plan_propose: propose an ExecutionPlan and request operator approval.",
      "- labos_plan_update: publish live plan progress (pending / in_progress / completed).",
      "- labos_run_execute: execute the approved plan steps.",
      "",
      "# ExecutionPlan JSON shape (for labos_plan_propose)",
      "{",
      '  "steps": [',
      "    {",
      '      "title": "string",',
      '      "runtime": "Python|Shell|Download|HPC Job|Notebook",',
      '      "inputs": ["string"],',
      '      "outputs": ["string"],',
      '      "riskFlags": ["Network access|Large download|Overwrite existing files"]',
      "    }",
      "  ]",
      "}",
      "",
      "# Judgment prompts (optional, for labos_plan_propose)",
      "Include judgment.questions[] when you need operator choices or notes.",
      "Each question has: id, header, question, options[{label,description}], allowFreeform.",
      "",
      "# Policy",
      opts.wantsPlan || opts.planMode
        ? [
            "- You MUST propose an ExecutionPlan and call labos_plan_propose before executing anything.",
            "- If approval is granted, call labos_run_execute to perform execution.",
            "- Use labos_plan_update to keep plan progress accurate during execution.",
          ].join("\n")
        : "- Respond normally. If you decide to execute, call labos_plan_propose first.",
    ].join("\n")
  );
  return sections.join("\n");
}

function estimateTokensForText(text: string): number {
  const raw = typeof text === "string" ? text : "";
  if (!raw) return 0;
  const bytes = Buffer.byteLength(raw, "utf8");
  if (!bytes) return 0;
  // Conservative heuristic; used for thresholding (auto-compaction) and UI estimates.
  return Math.ceil(bytes / 3);
}

function estimateInputTokensForRun(opts: {
  systemPrompt: string;
  transcript: Array<{ role: string; content: string }>;
  userText: string;
}): number {
  const perMessageOverhead = 6;
  let total = estimateTokensForText(opts.systemPrompt);
  for (const m of opts.transcript) {
    if (m.role !== "user" && m.role !== "assistant") continue;
    total += perMessageOverhead + estimateTokensForText(m.content);
  }
  total += perMessageOverhead + estimateTokensForText(opts.userText);
  return total;
}

function getOptionalNumberEnv(name: string): number | undefined {
  const raw = process.env[name];
  if (raw == null) return undefined;
  const n = Number(raw);
  return Number.isFinite(n) ? n : undefined;
}

function getOptionalReasoningEnv(name: string): SimpleStreamOptions["reasoning"] | undefined {
  const raw = process.env[name];
  if (!raw) return undefined;
  switch (String(raw).trim()) {
    case "minimal":
    case "low":
    case "medium":
    case "high":
    case "xhigh":
      return String(raw).trim() as SimpleStreamOptions["reasoning"];
    default:
      return undefined;
  }
}

async function streamAssistantFromModel(
  state: HubState,
  opts: {
    model: PiModel<any>;
    context: PiContext;
    thinkingLevel: string | null;
    agentRunId: string;
    projectId: string;
    sessionId: string;
    messageId: string;
  }
) {
  const temperature = getOptionalNumberEnv("LABOS_MODEL_TEMPERATURE");
  const maxTokens = getOptionalNumberEnv("LABOS_MODEL_MAX_TOKENS");
  const envReasoning = getOptionalReasoningEnv("LABOS_MODEL_REASONING");
  const reasoning = opts.model.reasoning
    ? (opts.thinkingLevel ? (opts.thinkingLevel as SimpleStreamOptions["reasoning"]) : envReasoning)
    : undefined;

  const options: SimpleStreamOptions = {
    ...(typeof temperature === "number" ? { temperature } : {}),
    ...(typeof maxTokens === "number" ? { maxTokens } : {}),
    ...(reasoning ? { reasoning } : {}),
  };

  const stream = streamSimple(opts.model as any, opts.context as any, options);

  let full = "";
  for await (const ev of stream) {
    if (ev.type === "text_delta") {
      const delta = ev.delta ?? "";
      if (!delta) continue;
      full += delta;
      broadcastEvent(state, "agent.stream.assistant_delta", {
        agentRunId: opts.agentRunId,
        projectId: opts.projectId,
        sessionId: opts.sessionId,
        messageId: opts.messageId,
        delta,
      });
    } else if (ev.type === "error") {
      const msg = ev.error?.errorMessage ?? "model error";
      throw new Error(msg);
    }
  }
  return full;
}

function chunkText(text: string, maxLen: number) {
  const out: string[] = [];
  let i = 0;
  while (i < text.length) {
    out.push(text.slice(i, i + maxLen));
    i += maxLen;
  }
  return out.length ? out : [""];
}

function buildStubPlan(projectId: string, sessionId: string, userText: string) {
  const normalized = userText.toLowerCase();
  const riskFlags: string[] = [];
  if (normalized.includes("download")) {
    riskFlags.push("Network access", "Large download");
  }
  const steps = [
    {
      id: uuidv4(),
      title: "Fetch source data",
      runtime: "Download",
      inputs: ["remote dataset endpoint"],
      outputs: ["uploads/source.csv"],
      riskFlags: riskFlags.filter((f) => f === "Network access" || f === "Large download"),
    },
    {
      id: uuidv4(),
      title: "Submit HPC job",
      runtime: "HPC Job",
      inputs: ["uploads/source.csv"],
      outputs: ["artifacts/hello.txt", "logs/run.log"],
      riskFlags: [],
    },
  ];

  return {
    id: uuidv4(),
    projectID: projectId,
    sessionID: sessionId,
    createdAt: new Date().toISOString(),
    steps,
  };
}

async function insertPlan(state: HubState, plan: any, agentRunId: string) {
  const planId = String(plan?.id ?? "");
  const projectId = String(plan?.projectID ?? "");
  const sessionId = String(plan?.sessionID ?? "");
  if (!planId || !projectId || !sessionId) {
    throw new Error("Invalid plan for insert");
  }
  await state.pool.query(
    `INSERT INTO plans (id, project_id, session_id, agent_run_id, status, plan, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [planId, projectId, sessionId, agentRunId, "requested", JSON.stringify(plan), new Date().toISOString()]
  );
}

async function waitForApproval(state: HubState, planId: string) {
  const existing = state.pendingApprovals.get(planId);
  if (existing) {
    clearTimeout(existing.timeout);
    state.pendingApprovals.delete(planId);
  }

  return await new Promise<{ decision: "approve" | "reject"; judgmentResponses?: { answers?: Record<string, string>; freeform?: Record<string, string> } }>(
    (resolve) => {
    const timeout = setTimeout(() => {
      state.pendingApprovals.delete(planId);
      resolve({ decision: "reject" });
    }, 60_000);
    state.pendingApprovals.set(planId, { resolve, timeout });
  }
  );
}

async function resolveApproval(
  state: HubState,
  planId: string,
  decision: "approve" | "reject",
  deviceId: string,
  judgmentResponses?: { answers?: Record<string, string>; freeform?: Record<string, string> }
) {
  const pending = state.pendingApprovals.get(planId);
  if (!pending) return false;

  clearTimeout(pending.timeout);
  state.pendingApprovals.delete(planId);

  await state.pool.query(
    "UPDATE plans SET status=$1, decision=$2, resolved_at=$3, resolved_by_device_id=$4 WHERE id=$5",
    ["resolved", decision, new Date().toISOString(), deviceId, planId]
  );

  broadcastEvent(state, "exec.approval.resolved", {
    planId,
    decision,
    resolvedAt: new Date().toISOString(),
  });

  pending.resolve({ decision, judgmentResponses });
  return true;
}

async function createRunRecord(state: HubState, opts: { id: string; projectId: string; sessionId: string; stepTitles: string[] }) {
  const now = new Date().toISOString();
  const totalSteps = Math.max(opts.stepTitles.length, 1);
  const permissionLevel = await getSessionPermissionLevel(state, opts.projectId, opts.sessionId).catch(() => "default");
  await state.pool.query(
    `INSERT INTO runs (id, project_id, session_id, status, initiated_at, current_step, total_steps, log_snippet, step_titles, produced_artifact_paths, permission_level)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
    [
      opts.id,
      opts.projectId,
      opts.sessionId,
      "queued",
      now,
      0,
      totalSteps,
      "Queued",
      JSON.stringify(opts.stepTitles),
      JSON.stringify([]),
      permissionLevel,
    ]
  );
  return {
    id: opts.id,
    projectID: opts.projectId,
    sessionID: opts.sessionId,
    status: "queued",
    initiatedAt: now,
    completedAt: null,
    currentStep: 0,
    totalSteps,
    logSnippet: "Queued",
    stepTitles: opts.stepTitles,
    producedArtifactPaths: [],
  };
}

async function executePlan(
  state: HubState,
  opts: { projectId: string; sessionId: string; agentRunId: string; plan: any; runId: string }
) {
  const node = state.node;
  const workspaceRoot = node?.ctx.permissions?.workspaceRoot as string | undefined;
  const permissionLevel = await getSessionPermissionLevel(state, opts.projectId, opts.sessionId).catch(() => "default");

  if (node && workspaceRoot) {
    const prefs = state.hpcPrefs;
    const nodeCommands = Array.isArray(node.ctx.commands) ? node.ctx.commands : [];
    const supportsShellExec = nodeCommands.includes("shell.exec");

    const workdir = `runs/${opts.runId}`;
    const command = [
      "bash",
      "-lc",
      "mkdir -p ../../artifacts ../../logs && echo \"hello from LabOS\" > ../../artifacts/hello.txt && echo \"done\" > ../../logs/run.log",
    ];

    if (permissionLevel === "full" && supportsShellExec) {
      await updateRun(state, opts.projectId, opts.runId, (run) => {
        run.status = "running";
        run.log_snippet = "Running on HPC shell";
        run.current_step = Math.max(1, run.current_step);
        return run;
      });

      const toolCallId = uuidv4();
      broadcastEvent(state, "agent.stream.tool_event", {
        agentRunId: opts.agentRunId,
        projectId: opts.projectId,
        sessionId: opts.sessionId,
        runId: opts.runId,
        toolCallId,
        tool: "shell.exec",
        phase: "start",
        summary: "Executing command on HPC shell",
        detail: { command, cwd: workdir, permissionLevel },
        ts: new Date().toISOString(),
      });
      await persistToolMessage(
        state,
        opts.projectId,
        opts.sessionId,
        `Tool call: shell.exec\nExecuting command on HPC shell`,
        opts.runId
      );

      try {
        const res = await callNode(state, "shell.exec", {
          projectId: opts.projectId,
          runId: opts.runId,
          command,
          cwd: workdir,
          timeoutMs: 10 * 60 * 1000,
          permissionLevel,
        });

        const artifacts = Array.isArray((res as any)?.artifacts) ? (res as any).artifacts : [];
        const producedArtifactPaths = artifacts.map((a: any) => String(a?.path ?? "")).filter(Boolean);

        broadcastEvent(state, "agent.stream.tool_event", {
          agentRunId: opts.agentRunId,
          projectId: opts.projectId,
          sessionId: opts.sessionId,
          runId: opts.runId,
          toolCallId,
          tool: "shell.exec",
          phase: "end",
          summary: "Command complete",
          detail: { result: res },
          ts: new Date().toISOString(),
        });
        await persistToolMessage(
          state,
          opts.projectId,
          opts.sessionId,
          `Tool call: shell.exec\nCommand complete`,
          opts.runId
        );

        await updateRun(state, opts.projectId, opts.runId, (run) => {
          run.status = "succeeded";
          run.completed_at = new Date().toISOString();
          run.current_step = Math.max(run.total_steps, 1);
          run.log_snippet = "Completed";
          run.produced_artifact_paths = JSON.stringify(producedArtifactPaths);
          return run;
        });

        broadcastEvent(state, "runs.updated", {
          projectId: opts.projectId,
          run: await getRun(state, opts.projectId, opts.runId),
          change: "updated",
        });
      } catch (err: any) {
        broadcastEvent(state, "agent.stream.tool_event", {
          agentRunId: opts.agentRunId,
          projectId: opts.projectId,
          sessionId: opts.sessionId,
          runId: opts.runId,
          toolCallId,
          tool: "shell.exec",
          phase: "error",
          summary: "Failed executing command on HPC shell",
          detail: { error: String(err?.message ?? err ?? "unknown error") },
          ts: new Date().toISOString(),
        });
        await persistToolMessage(
          state,
          opts.projectId,
          opts.sessionId,
          `Tool call: shell.exec\nFailed executing command on HPC shell`,
          opts.runId
        );
        throw err;
      }

      return;
    }

    // For v0.1, submit a single simple job that produces artifacts.
    const jobSpec = {
      name: `labos-run-${opts.runId.slice(0, 8)}`,
      command,
      workdir,
      resources: {
        partition: prefs?.partition,
        account: prefs?.account,
        qos: prefs?.qos,
        timeLimitMinutes: 10,
        cpus: 1,
        memMB: 512,
      },
      outputs: {
        artifactRoots: ["artifacts"],
        logDir: "logs",
        stdoutFile: "logs/slurm-%j.out",
        stderrFile: "logs/slurm-%j.err",
      },
    };

    await updateRun(state, opts.projectId, opts.runId, (run) => {
      run.status = "queued";
      run.log_snippet = "Submitting Slurm job";
      return run;
    });

    const toolCallId = uuidv4();
    broadcastEvent(state, "agent.stream.tool_event", {
      agentRunId: opts.agentRunId,
      projectId: opts.projectId,
      sessionId: opts.sessionId,
      runId: opts.runId,
      toolCallId,
      tool: "slurm.submit",
      phase: "start",
      summary: "Submitting Slurm job",
      detail: { job: jobSpec },
      ts: new Date().toISOString(),
    });
    await persistToolMessage(
      state,
      opts.projectId,
      opts.sessionId,
      `Tool call: slurm.submit\nSubmitting Slurm job`,
      opts.runId
    );

    try {
      const res = await callNode(state, "slurm.submit", {
        projectId: opts.projectId,
        runId: opts.runId,
        job: jobSpec,
        staging: { uploads: [] },
        permissionLevel,
      });

      broadcastEvent(state, "agent.stream.tool_event", {
        agentRunId: opts.agentRunId,
        projectId: opts.projectId,
        sessionId: opts.sessionId,
        runId: opts.runId,
        toolCallId,
        tool: "slurm.submit",
        phase: "end",
        summary: "Submitted Slurm job",
        detail: { result: res },
        ts: new Date().toISOString(),
      });
      await persistToolMessage(
        state,
        opts.projectId,
        opts.sessionId,
        `Tool call: slurm.submit\nSubmitted Slurm job`,
        opts.runId
      );

      await updateRun(state, opts.projectId, opts.runId, (run) => {
        run.hpc_job_id = String((res as any).jobId ?? "");
        run.log_snippet = "Queued";
        return run;
      });
    } catch (err: any) {
      broadcastEvent(state, "agent.stream.tool_event", {
        agentRunId: opts.agentRunId,
        projectId: opts.projectId,
        sessionId: opts.sessionId,
        runId: opts.runId,
        toolCallId,
        tool: "slurm.submit",
        phase: "error",
        summary: "Failed submitting Slurm job",
        detail: { error: String(err?.message ?? err ?? "unknown error") },
        ts: new Date().toISOString(),
      });
      await persistToolMessage(
        state,
        opts.projectId,
        opts.sessionId,
        `Tool call: slurm.submit\nFailed submitting Slurm job`,
        opts.runId
      );
      throw err;
    }

    // Node will drive subsequent status/log/artifact events.
    return;
  }

  // No node: simulate run and write a local generated artifact.
  for (let i = 0; i < opts.plan.steps.length; i++) {
    const step = opts.plan.steps[i];
    await updateRun(state, opts.projectId, opts.runId, (run) => {
      run.status = "running";
      run.current_step = i + 1;
      run.log_snippet = `Running: ${step.title}`;
      return run;
    });

    broadcastEvent(state, "runs.updated", {
      projectId: opts.projectId,
      run: await getRun(state, opts.projectId, opts.runId),
      change: "updated",
    });

    await sleep(450);
  }

  const produced = ["artifacts/hello.txt", "logs/run.log"];
  await writeGeneratedArtifact(state, opts.projectId, "artifacts/hello.txt", `hello from LabOS (run ${opts.runId})\n`);
  await writeGeneratedArtifact(state, opts.projectId, "logs/run.log", `run ${opts.runId} complete\n`);

  for (const p of produced) {
    await upsertArtifact(state, {
      projectId: opts.projectId,
      path: p,
      origin: "generated",
      modifiedAt: new Date().toISOString(),
    });
  }

  await updateRun(state, opts.projectId, opts.runId, (run) => {
    run.status = "succeeded";
    run.completed_at = new Date().toISOString();
    run.current_step = Math.max(run.total_steps, 1);
    run.log_snippet = "Completed";
    run.produced_artifact_paths = JSON.stringify(produced);
    return run;
  });

  broadcastEvent(state, "runs.updated", {
    projectId: opts.projectId,
    run: await getRun(state, opts.projectId, opts.runId),
    change: "updated",
  });

  for (const p of produced) {
    broadcastEvent(state, "artifacts.updated", {
      projectId: opts.projectId,
      artifact: await getArtifactByPath(state, opts.projectId, p),
      change: "created",
    });
  }

  const artifactRefs = produced.map((p) => ({
    displayText: p,
    projectID: opts.projectId,
    path: p,
    artifactID: null,
  }));

  await persistAssistantMessage(state, {
    projectId: opts.projectId,
    sessionId: opts.sessionId,
    id: uuidv4(),
    text: `Run completed. Generated ${produced.length} artifacts.`,
    proposedPlan: null,
    artifactRefs,
    runId: opts.runId,
  });
}

async function updateRun(state: HubState, projectId: string, runId: string, mutator: (row: any) => any) {
  const res = await state.pool.query("SELECT * FROM runs WHERE id=$1 AND project_id=$2", [runId, projectId]);
  if (res.rows.length === 0) return;
  const row: any = res.rows[0];
  const updated = mutator(row);
  const stepTitlesJson = typeof updated.step_titles === "string" ? updated.step_titles : JSON.stringify(updated.step_titles ?? []);
  const producedPathsJson =
    typeof updated.produced_artifact_paths === "string"
      ? updated.produced_artifact_paths
      : JSON.stringify(updated.produced_artifact_paths ?? []);
  await state.pool.query(
    `UPDATE runs SET status=$1, completed_at=$2, current_step=$3, total_steps=$4, log_snippet=$5, step_titles=$6,
       produced_artifact_paths=$7, hpc_job_id=$8 WHERE id=$9 AND project_id=$10`,
    [
      updated.status,
      updated.completed_at,
      updated.current_step,
      updated.total_steps,
      updated.log_snippet,
      stepTitlesJson,
      producedPathsJson,
      updated.hpc_job_id,
      runId,
      projectId,
    ]
  );
}

async function updateRunCurrentStep(
  state: HubState,
  opts: { projectId: string; runId: string; currentStep: number; logSnippet: string }
) {
  await updateRun(state, opts.projectId, opts.runId, (run) => {
    run.status = "running";
    run.current_step = Math.max(0, Math.floor(opts.currentStep));
    run.log_snippet = String(opts.logSnippet ?? "");
    return run;
  });

  const runRecord = await getRun(state, opts.projectId, opts.runId);
  if (!runRecord) return;
  broadcastEvent(state, "runs.updated", { projectId: opts.projectId, run: runRecord, change: "updated" });
}

async function listRuns(state: HubState, projectId: string) {
  const res = await state.pool.query("SELECT * FROM runs WHERE project_id=$1 ORDER BY initiated_at DESC", [projectId]);
  return res.rows.map(mapRunRecord);
}

async function getRun(state: HubState, projectId: string, runId: string) {
  const res = await state.pool.query("SELECT * FROM runs WHERE project_id=$1 AND id=$2", [projectId, runId]);
  if (res.rows.length === 0) return null;
  return mapRunRecord(res.rows[0] as any);
}

function mapRunRecord(r: any) {
  return {
    id: r.id,
    projectID: r.project_id,
    sessionID: r.session_id,
    status: r.status,
    initiatedAt: toIso(r.initiated_at),
    completedAt: r.completed_at ? toIso(r.completed_at) : null,
    currentStep: r.current_step,
    totalSteps: r.total_steps,
    logSnippet: r.log_snippet,
    stepTitles: parseJson(r.step_titles, []),
    producedArtifactPaths: parseJson(r.produced_artifact_paths, []),
    hpcJobId: r.hpc_job_id ?? null,
  };
}

async function listArtifacts(state: HubState, projectId: string, opts: { prefix: string | null }) {
  const args: any[] = [projectId];
  let sql = "SELECT * FROM artifacts WHERE project_id=$1";
  if (opts.prefix) {
    args.push(`${opts.prefix}%`);
    sql += ` AND path LIKE $${args.length}`;
  }
  sql += " ORDER BY path ASC";
  const res = await state.pool.query(sql, args);
  return res.rows.map(mapArtifact);
}

async function getArtifactByPath(state: HubState, projectId: string, artifactPath: string) {
  const res = await state.pool.query("SELECT * FROM artifacts WHERE project_id=$1 AND path=$2", [projectId, artifactPath]);
  if (res.rows.length === 0) return null;
  return mapArtifact(res.rows[0] as any);
}

function mapArtifact(r: any) {
  return {
    id: r.id,
    projectID: r.project_id,
    path: r.path,
    kind: r.kind,
    origin: r.origin,
    modifiedAt: toIso(r.modified_at),
    sizeBytes: r.size_bytes == null ? null : Number(r.size_bytes),
    createdBySessionID: r.created_by_session_id ?? null,
    createdByRunID: r.created_by_run_id ?? null,
  };
}

async function upsertArtifact(
  state: HubState,
  artifact: { projectId: string; path: string; origin: "user_upload" | "generated"; modifiedAt: string; sizeBytes?: number }
) {
  const kind = inferArtifactKind(artifact.path);
  const id = uuidv4();
  await state.pool.query(
    `INSERT INTO artifacts (id, project_id, path, kind, origin, modified_at, size_bytes)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (project_id, path) DO UPDATE SET
       kind=EXCLUDED.kind,
       origin=EXCLUDED.origin,
       modified_at=EXCLUDED.modified_at,
       size_bytes=COALESCE(EXCLUDED.size_bytes, artifacts.size_bytes)`,
    [id, artifact.projectId, artifact.path, kind, artifact.origin, artifact.modifiedAt, artifact.sizeBytes ?? null]
  );
}

function inferArtifactKind(p: string) {
  const ext = path.posix.extname(p).toLowerCase().replace(".", "");
  switch (ext) {
    case "ipynb":
      return "notebook";
    case "py":
      return "python";
    case "png":
    case "jpg":
    case "jpeg":
      return "image";
    case "txt":
    case "md":
      return "text";
    case "json":
      return "json";
    case "log":
      return "log";
    default:
      return "unknown";
  }
}

async function persistAssistantMessage(state: HubState, msg: {
  projectId: string;
  sessionId: string;
  id: string;
  text: string;
  proposedPlan: any | null;
  artifactRefs: any[];
  usage?: { input: number; output: number; totalTokens: number } | null;
  modelId?: string;
  contextWindowTokens?: number;
  runId?: string;
}) {
  const now = new Date().toISOString();
  const message = {
    id: msg.id,
    sessionID: msg.sessionId,
    role: "assistant",
    text: msg.text,
    createdAt: now,
    artifactRefs: msg.artifactRefs,
    proposedPlan: msg.proposedPlan,
    runID: msg.runId ?? null,
    parentID: null,
  };

  await appendTranscriptLine(state, msg.projectId, msg.sessionId, {
    id: msg.id,
    ts: now,
    role: "assistant",
    content: msg.text,
    artifactRefs: msg.artifactRefs,
    proposedPlan: msg.proposedPlan,
    runId: msg.runId ?? null,
  });

  await state.pool.query(
    `INSERT INTO messages (id, project_id, session_id, ts, role, content, artifact_refs, proposed_plan, run_id, parent_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [
      msg.id,
      msg.projectId,
      msg.sessionId,
      now,
      "assistant",
      msg.text,
      JSON.stringify(msg.artifactRefs ?? []),
      msg.proposedPlan ? JSON.stringify(msg.proposedPlan) : null,
      msg.runId ?? null,
      null,
    ]
  );

  await state.pool.query(
    `UPDATE sessions SET
       updated_at=$1,
       last_message_preview=$2,
       last_message_at=$1,
       context_model_id=COALESCE($3, context_model_id),
       context_window_tokens=COALESCE($4, context_window_tokens),
       context_used_input_tokens=COALESCE($5, context_used_input_tokens),
       context_used_tokens=COALESCE($6, context_used_tokens),
       context_updated_at=COALESCE($7, context_updated_at)
     WHERE id=$8 AND project_id=$9`,
    [
      now,
      preview(msg.text),
      msg.modelId ?? null,
      msg.contextWindowTokens ?? null,
      msg.usage ? Math.max(0, Math.floor(msg.usage.input)) : null,
      msg.usage ? Math.max(0, Math.floor(msg.usage.totalTokens)) : null,
      msg.usage ? now : null,
      msg.sessionId,
      msg.projectId,
    ]
  );

  broadcastEvent(state, "chat.message.created", { projectId: msg.projectId, sessionId: msg.sessionId, message });

  if (msg.usage && typeof msg.contextWindowTokens === "number" && Number.isFinite(msg.contextWindowTokens)) {
    const usedInputTokens = Math.max(0, Math.floor(msg.usage.input));
    const usedTokens = Math.max(0, Math.floor(msg.usage.totalTokens));
    const total = Math.max(1, Math.floor(msg.contextWindowTokens));
    const remainingTokens = Math.max(0, total - usedInputTokens);
    broadcastEvent(state, "sessions.context.updated", {
      projectId: msg.projectId,
      sessionId: msg.sessionId,
      modelId: typeof msg.modelId === "string" ? msg.modelId : null,
      contextWindowTokens: total,
      usedInputTokens,
      usedTokens,
      remainingTokens,
      updatedAt: now,
    });
  }
}

async function persistToolMessage(state: HubState, projectId: string, sessionId: string, text: string, runId?: string) {
  const now = new Date().toISOString();
  const id = uuidv4();
  const message = {
    id,
    sessionID: sessionId,
    role: "tool",
    text,
    createdAt: now,
    artifactRefs: [],
    proposedPlan: null,
    runID: runId ?? null,
    parentID: null,
  };

  await appendTranscriptLine(state, projectId, sessionId, {
    id,
    ts: now,
    role: "tool",
    content: text,
    artifactRefs: [],
    proposedPlan: null,
    runId: runId ?? null,
  });

  await state.pool.query(
    `INSERT INTO messages (id, project_id, session_id, ts, role, content, artifact_refs, proposed_plan, run_id, parent_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [id, projectId, sessionId, now, "tool", text, JSON.stringify([]), null, runId ?? null, null]
  );

  broadcastEvent(state, "chat.message.created", { projectId, sessionId, message });
}

async function ensureProjectDirs(state: HubState, projectId: string) {
  await mkdir(projectDir(state, projectId), { recursive: true });
  await mkdir(projectBootstrapDir(state, projectId), { recursive: true });
  await mkdir(projectSessionsDir(state, projectId), { recursive: true });
  await mkdir(projectUploadsDir(state, projectId), { recursive: true });
  await mkdir(projectCacheDir(state, projectId), { recursive: true });
  await mkdir(projectGeneratedDir(state, projectId), { recursive: true });
}

async function ensureBootstrapDefaults(state: HubState, projectId: string) {
  const files: Array<[string, string]> = [
    [
      "AGENTS.md",
      `# AGENTS.md\n\n- This workspace is managed by LabOS Hub.\n- Session memory is the canonical chat transcript JSONL.\n- Bootstrap memory files are injected into the agent context on every run.\n`,
    ],
    [
      "USERS.md",
      `# USERS.md\n\n- Preferences: iPhone-first UI, streaming chat, approvals.\n- Default: ask for confirmation before any side effects.\n`,
    ],
    ["SOUL.md", `# SOUL.md\n\n- Identity: LabOS research assistant.\n- Tone: concise, direct, friendly.\n`],
    ["TOOLS.md", `# TOOLS.md\n\n- Approvals gate any side effects.\n`],
  ];

  for (const [name, content] of files) {
    const filePath = path.join(projectBootstrapDir(state, projectId), name);
    try {
      await stat(filePath);
    } catch {
      if (name === "USERS.md") {
        const legacyPath = path.join(projectBootstrapDir(state, projectId), "USER.md");
        if (existsSync(legacyPath)) {
          const legacy = await readFile(legacyPath, "utf8").catch(() => null);
          if (legacy != null) {
            await writeFile(filePath, legacy, "utf8");
            continue;
          }
        }
      }
      await writeFile(filePath, content, "utf8");
    }
  }
}

async function getBootstrapFiles(state: HubState, projectId: string) {
  try {
    await stat(projectDir(state, projectId));
  } catch {
    return [];
  }
  const dir = projectBootstrapDir(state, projectId);
  const names = ["AGENTS.md", "USERS.md", "SOUL.md", "TOOLS.md"];
  const out: Array<{ name: string; content: string }> = [];
  for (const name of names) {
    const filePath = name === "USERS.md" ? resolveUsersBootstrapPath(dir) : path.join(dir, name);
    try {
      const content = await readFile(filePath, "utf8");
      out.push({ name, content });
    } catch {
      out.push({ name, content: "" });
    }
  }
  return out;
}

async function updateBootstrapFile(state: HubState, projectId: string, name: string, content: string) {
  const normalized = normalizeBootstrapFilename(name);
  if (!normalized) return false;
  try {
    await stat(projectDir(state, projectId));
  } catch {
    return false;
  }
  await mkdir(projectBootstrapDir(state, projectId), { recursive: true });
  const dir = projectBootstrapDir(state, projectId);
  const target = normalized === "USERS.md" ? resolveUsersBootstrapPath(dir, { preferLegacyIfPresent: true }) : path.join(dir, normalized);
  await writeFile(target, content, "utf8");
  return true;
}

function normalizeBootstrapFilename(name: string): "AGENTS.md" | "USERS.md" | "SOUL.md" | "TOOLS.md" | null {
  const n = String(name ?? "").trim().toUpperCase();
  switch (n) {
    case "AGENTS.MD":
      return "AGENTS.md";
    case "USERS.MD":
    case "USER.MD":
      return "USERS.md";
    case "SOUL.MD":
      return "SOUL.md";
    case "TOOLS.MD":
      return "TOOLS.md";
    default:
      return null;
  }
}

function resolveUsersBootstrapPath(dir: string, opts?: { preferLegacyIfPresent?: boolean }) {
  const usersPath = path.join(dir, "USERS.md");
  if (existsSync(usersPath)) return usersPath;
  const legacyPath = path.join(dir, "USER.md");
  if (existsSync(legacyPath)) return legacyPath;
  if (opts?.preferLegacyIfPresent && existsSync(legacyPath)) return legacyPath;
  return usersPath;
}

async function appendTranscriptLine(state: HubState, projectId: string, sessionId: string, obj: any) {
  await mkdir(projectSessionsDir(state, projectId), { recursive: true });
  await appendFile(sessionTranscriptPath(state, projectId, sessionId), JSON.stringify(obj) + "\n", "utf8");
}

async function loadTranscriptMessagesFromJsonl(
  state: HubState,
  projectId: string,
  sessionId: string,
  opts: { limit: number }
): Promise<Array<{ ts: string; role: string; content: string }>> {
  const transcriptPath = sessionTranscriptPath(state, projectId, sessionId);
  const raw = await readFile(transcriptPath, "utf8").catch(() => "");
  const lines = raw.split(/\r?\n/);
  const out: Array<{ ts: string; role: string; content: string }> = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const obj: any = JSON.parse(line);
      if (!obj || typeof obj.role !== "string" || typeof obj.content !== "string") continue;
      out.push({ ts: toIso(obj.ts), role: obj.role, content: obj.content });
    } catch {
      // ignore parse errors
    }
  }
  return out.slice(Math.max(0, out.length - Math.max(1, Math.floor(opts.limit))));
}

async function buildRunContext(state: HubState, projectId: string, sessionId: string, opts: { historyLimit: number }) {
  const [bootstrap, transcript] = await Promise.all([
    getBootstrapFiles(state, projectId),
    loadTranscriptMessagesFromJsonl(state, projectId, sessionId, { limit: opts.historyLimit }),
  ]);
  return { bootstrap, transcript };
}

async function loadTranscriptEntriesFromJsonl(state: HubState, projectId: string, sessionId: string): Promise<any[]> {
  const transcriptPath = sessionTranscriptPath(state, projectId, sessionId);
  const raw = await readFile(transcriptPath, "utf8").catch(() => "");
  const lines = raw.split(/\r?\n/);
  const out: any[] = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    try {
      const obj: any = JSON.parse(line);
      if (!obj || typeof obj.role !== "string" || typeof obj.content !== "string") continue;
      out.push({
        ...obj,
        ts: toIso(obj.ts),
        role: String(obj.role),
        content: String(obj.content),
      });
    } catch {
      // ignore parse errors
    }
  }
  return out;
}

async function writeTranscriptEntriesToJsonl(state: HubState, projectId: string, sessionId: string, entries: any[]) {
  await mkdir(projectSessionsDir(state, projectId), { recursive: true });
  const body = entries.map((e) => JSON.stringify(e)).join("\n") + "\n";
  await writeFile(sessionTranscriptPath(state, projectId, sessionId), body, "utf8");
}

function isCompactionSummaryEntry(entry: any): boolean {
  return entry?.role === "assistant" && typeof entry?.content === "string" && entry.content.startsWith("[LABOS_COMPACT_SUMMARY");
}

function extractCompactionSummaryText(raw: string): string {
  const idx = raw.indexOf("\n");
  if (idx === -1) return "";
  return raw.slice(idx + 1).trim();
}

function formatEntriesForCompaction(entries: any[]): string {
  const out: string[] = [];
  for (const e of entries) {
    const role = String(e?.role ?? "unknown");
    const content = String(e?.content ?? "");
    if (!content.trim()) continue;
    const prefix = role === "user" ? "User" : role === "assistant" ? "Assistant" : role;
    out.push(`${prefix}:\n${content.trim()}`);
  }
  return out.join("\n\n---\n\n");
}

function chunkEntriesByTokenBudget(entries: any[], budgetTokens: number): any[][] {
  const budget = Math.max(200, Math.floor(budgetTokens));
  const chunks: any[][] = [];
  let current: any[] = [];
  let currentTokens = 0;
  for (const e of entries) {
    const t = estimateTokensForText(String(e?.content ?? "")) + 10;
    if (current.length > 0 && currentTokens + t > budget) {
      chunks.push(current);
      current = [];
      currentTokens = 0;
    }
    current.push(e);
    currentTokens += t;
  }
  if (current.length > 0) chunks.push(current);
  return chunks;
}

async function summarizeForCompaction(state: HubState, opts: {
  model: PiModel<any>;
  apiKey: string;
  existingSummary: string;
  entries: any[];
  maxOutputTokens: number;
}): Promise<string> {
  const systemPrompt = [
    "You are compacting a chat transcript into a durable session memory summary for an AI agent.",
    "",
    "Requirements:",
    "- Preserve all important facts, decisions, constraints, names, IDs, file paths, commands, and open TODOs.",
    "- Be concise and structured (bullets + short headings).",
    "- Do NOT include filler or meta commentary.",
    `- Keep the entire summary under ${Math.max(200, Math.floor(opts.maxOutputTokens))} tokens.`,
    "- Output ONLY the updated summary text.",
  ].join("\n");

  const userText = [
    "Existing summary (may be empty):",
    opts.existingSummary.trim() ? opts.existingSummary.trim() : "(none)",
    "",
    "New messages to incorporate:",
    formatEntriesForCompaction(opts.entries),
  ].join("\n");

  const context: PiContext = {
    systemPrompt,
    messages: [{ role: "user", content: userText, timestamp: Date.now() }],
  };

  const options: SimpleStreamOptions = {
    apiKey: opts.apiKey,
    temperature: 0.2,
    maxTokens: Math.max(200, Math.floor(opts.maxOutputTokens)),
  };

  const stream = streamSimple(opts.model as any, context as any, options);
  let full = "";
  for await (const ev of stream) {
    if (ev.type === "text_delta") {
      full += ev.delta ?? "";
    } else if (ev.type === "error") {
      const msg = ev.error?.errorMessage ?? "model error";
      throw new Error(msg);
    }
  }
  return full.trim();
}

async function compactSessionTranscript(state: HubState, opts: {
  projectId: string;
  sessionId: string;
  model: PiModel<any>;
  apiKey: string;
  contextWindowTokens: number;
  currentUserText: string;
  trigger: "auto" | "overflow" | "manual";
}): Promise<boolean> {
  const all = await loadTranscriptEntriesFromJsonl(state, opts.projectId, opts.sessionId);
  const msgs = all.filter((e) => e?.role === "user" || e?.role === "assistant");
  if (msgs.length < 2) return false;

  const summaryEntries = msgs.filter(isCompactionSummaryEntry);
  const existingSummary = summaryEntries.length > 0 ? extractCompactionSummaryText(summaryEntries[summaryEntries.length - 1].content) : "";
  const cleanMsgs = msgs.filter((e) => !isCompactionSummaryEntry(e));

  const keepRecentTokens = Math.min(50_000, Math.floor(Math.max(1, opts.contextWindowTokens) * 0.25));
  const maxKeepMessages = 120;
  const minKeepMessages = 8;

  const tail: any[] = [];
  let tailTokens = 0;
  for (let i = cleanMsgs.length - 1; i >= 0; i--) {
    const e = cleanMsgs[i]!;
    tail.unshift(e);
    tailTokens += estimateTokensForText(String(e.content ?? "")) + 10;
    if (tail.length >= minKeepMessages && tailTokens >= keepRecentTokens) break;
    if (tail.length >= maxKeepMessages) break;
  }

  const headCount = Math.max(0, cleanMsgs.length - tail.length);
  const toSummarize = cleanMsgs.slice(0, headCount);
  if (toSummarize.length === 0) return false;

  const chunkBudget = Math.max(1500, Math.min(12_000, Math.floor(Math.max(1, opts.contextWindowTokens) * 0.15)));
  const chunks = chunkEntriesByTokenBudget(toSummarize, chunkBudget);

  let summary = existingSummary;
  const maxOutputTokens = Math.max(600, Math.min(1800, Math.floor(Math.max(1, opts.contextWindowTokens) * 0.05)));

  for (const chunk of chunks) {
    summary = await summarizeForCompaction(state, {
      model: opts.model,
      apiKey: opts.apiKey,
      existingSummary: summary,
      entries: chunk,
      maxOutputTokens,
    });
  }

  if (!summary.trim()) return false;

  const now = new Date().toISOString();
  const summaryEntry = {
    id: uuidv4(),
    ts: now,
    role: "assistant",
    content: [`[LABOS_COMPACT_SUMMARY v1 ${opts.trigger} ${now}]`, summary.trim()].join("\n"),
    artifactRefs: [],
    proposedPlan: null,
    runId: null,
  };

  await writeTranscriptEntriesToJsonl(state, opts.projectId, opts.sessionId, [summaryEntry, ...tail]);
  await state.pool.query("UPDATE sessions SET last_compacted_at=$1 WHERE project_id=$2 AND id=$3", [now, opts.projectId, opts.sessionId]);

  return true;
}

async function writeGeneratedArtifact(state: HubState, projectId: string, relativePath: string, content: string) {
  const clean = normalizeRelativePath(relativePath);
  if (!clean) return;
  const outPath = path.join(projectGeneratedDir(state, projectId), clean);
  await mkdir(path.dirname(outPath), { recursive: true });
  await writeFile(outPath, content, "utf8");
}

async function repairMessagesFromJsonl(state: HubState) {
  const root = path.join(state.stateDir, "projects");
  const projects = await readdir(root).catch(() => []);
  for (const projectId of projects) {
    const sessionsPath = path.join(root, projectId, "sessions");
    const files = await readdir(sessionsPath).catch(() => []);
    for (const file of files) {
      if (!file.endsWith(".jsonl")) continue;
      const sessionId = file.slice(0, -".jsonl".length);
      const transcriptPath = path.join(sessionsPath, file);
      const raw = await readFile(transcriptPath, "utf8").catch(() => "");
      const lines = raw.split("\n").filter((l) => l.trim());
      const entries: any[] = [];
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          if (!entry || !entry.id || !entry.ts || !entry.role) continue;
          entries.push(entry);
        } catch {
          continue;
        }
      }

      const countRes = await state.pool.query<{ count: string }>(
        "SELECT COUNT(1) as count FROM messages WHERE project_id=$1 AND session_id=$2",
        [projectId, sessionId]
      );
      const dbCount = Number(countRes.rows[0]?.count ?? "0");
      const transcriptCount = entries.length;
      // The JSONL transcript is treated as the agent "memory" and may be compacted,
      // so it can legitimately have fewer entries than the UI message log in SQLite.
      // Only repair the DB when it is missing transcript entries.
      if (dbCount >= transcriptCount) continue;

      for (const entry of entries) {
        const role = String(entry.role);
        const content = String(entry.content ?? "");
        const artifactRefs = entry.artifactRefs ?? [];
        const proposedPlan = entry.proposedPlan ?? null;
        await state.pool.query(
          `INSERT INTO messages (id, project_id, session_id, ts, role, content, artifact_refs, proposed_plan)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           ON CONFLICT (id) DO NOTHING`,
          [entry.id, projectId, sessionId, entry.ts, role, content, JSON.stringify(artifactRefs), proposedPlan ? JSON.stringify(proposedPlan) : null]
        );
      }
    }
  }
}

async function handleNodeEvent(state: HubState, event: string, payload: any) {
  switch (event) {
    case "node.heartbeat": {
      state.resources.computeConnected = true;
      if (typeof payload.queueDepth === "number") state.resources.queueDepth = payload.queueDepth;
      if (typeof payload.storageUsedPercent === "number") state.resources.storageUsedPercent = payload.storageUsedPercent;
      if (typeof payload.cpuPercent === "number") state.resources.cpuPercent = payload.cpuPercent;
      if (typeof payload.ramPercent === "number") state.resources.ramPercent = payload.ramPercent;
      if (Object.prototype.hasOwnProperty.call(payload ?? {}, "hpc")) {
        state.resources.hpc = normalizeHpcStatus(payload?.hpc);
      }
      return;
    }
    case "runs.log.delta": {
      broadcastEvent(state, "runs.log.delta", payload);
      return;
    }
    case "artifacts.updated": {
      const projectId = String(payload.projectId ?? "");
      const artifacts = Array.isArray(payload.artifacts) ? payload.artifacts : [];
      for (const a of artifacts) {
        const p = String(a.path ?? "");
        if (!projectId || !p) continue;
        await upsertArtifact(state, {
          projectId,
          path: p,
          origin: "generated",
          modifiedAt: typeof a.modifiedAt === "string" ? a.modifiedAt : new Date().toISOString(),
          sizeBytes: typeof a.sizeBytes === "number" ? a.sizeBytes : undefined,
        });
        broadcastEvent(state, "artifacts.updated", {
          projectId,
          artifact: await getArtifactByPath(state, projectId, p),
          change: "updated",
        });
      }
      return;
    }
    case "slurm.job.updated": {
      const projectId = String(payload.projectId ?? "");
      const runId = String(payload.runId ?? "");
      const stateStr = String(payload.state ?? "");
      if (!projectId || !runId) return;

      const mapped = mapSlurmState(stateStr);
      await updateRun(state, projectId, runId, (run) => {
        run.status = mapped.status;
        run.log_snippet = mapped.logSnippet;
        if (mapped.completed) {
          run.completed_at = new Date().toISOString();
          if (typeof run.total_steps === "number" && run.current_step < run.total_steps) {
            run.current_step = run.total_steps;
          }
        } else if (typeof run.current_step === "number" && run.current_step < 1) {
          run.current_step = 1;
        }
        return run;
      });
      broadcastEvent(state, "runs.updated", {
        projectId,
        run: await getRun(state, projectId, runId),
        change: "updated",
      });
      return;
    }
    default:
      return;
  }
}

function mapSlurmState(stateStr: string) {
  const s = stateStr.toUpperCase();
  if (s.includes("RUNNING")) return { status: "running", logSnippet: "Running", completed: false };
  if (s.includes("COMPLETED")) return { status: "succeeded", logSnippet: "Completed", completed: true };
  if (s.includes("CANCELLED")) return { status: "canceled", logSnippet: "Canceled", completed: true };
  if (s.includes("FAILED")) return { status: "failed", logSnippet: "Failed", completed: true };
  return { status: "queued", logSnippet: s || "Queued", completed: false };
}

async function callNode(state: HubState, method: string, params: any) {
  const node = state.node;
  if (!node) throw new Error("NODE_OFFLINE");
  const id = uuidv4();
  const frame = { type: "req", id, method, params };
  node.ws.send(JSON.stringify(frame));

  return await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      state.pendingNodeRequests.delete(id);
      reject(new Error("node request timeout"));
    }, 60_000);
    state.pendingNodeRequests.set(id, { resolve, reject, timeout });
  });
}

function projectDir(state: HubState, projectId: string) {
  return path.join(state.stateDir, "projects", projectId);
}

function projectBootstrapDir(state: HubState, projectId: string) {
  return path.join(projectDir(state, projectId), "bootstrap");
}

function projectSessionsDir(state: HubState, projectId: string) {
  return path.join(projectDir(state, projectId), "sessions");
}

function projectUploadsDir(state: HubState, projectId: string) {
  return path.join(projectDir(state, projectId), "uploads");
}

function projectCacheDir(state: HubState, projectId: string) {
  return path.join(projectDir(state, projectId), "cache");
}

function projectGeneratedDir(state: HubState, projectId: string) {
  return path.join(projectCacheDir(state, projectId), "generated");
}

function sessionTranscriptPath(state: HubState, projectId: string, sessionId: string) {
  return path.join(projectSessionsDir(state, projectId), `${sessionId}.jsonl`);
}

function preview(text: string) {
  const t = text.replace(/\s+/g, " ").trim();
  return t.length > 140 ? t.slice(0, 140) + "…" : t;
}

function toIso(value: any) {
  if (!value) return new Date().toISOString();
  if (typeof value === "string") return value;
  if (value instanceof Date) return value.toISOString();
  return String(value);
}

function oauthProviderToModelProvider(oauthProviderId: string): string | null {
  switch (oauthProviderId) {
    case "openai-codex":
      return "openai-codex";
    case "anthropic":
      return "anthropic";
    case "github-copilot":
      return "github-copilot";
    case "google-gemini-cli":
      return "google-gemini-cli";
    case "google-antigravity":
      return "google-antigravity";
    default:
      return null;
  }
}

async function getApiKeyForProvider(state: HubState, provider: string): Promise<string | undefined> {
  const p = String(provider ?? "").trim();
  if (!p) return undefined;

  const ai = state.config.ai;
  const auth = ai?.auth;

  if (auth?.type === "api_key") {
    if (auth.provider === p && auth.apiKey) return auth.apiKey;
  } else if (auth?.type === "oauth") {
    const modelProvider = oauthProviderToModelProvider(auth.oauthProviderId);
    if (modelProvider === p) {
      const oauth = getOAuthProvider(auth.oauthProviderId);
      if (!oauth) return undefined;

      const creds: any = auth.credentials;
      if (!creds || typeof creds.refresh !== "string" || typeof creds.access !== "string" || typeof creds.expires !== "number") {
        return undefined;
      }

      if (Date.now() >= creds.expires - 60_000) {
        const lockKey = auth.oauthProviderId;
        const existing = state.oauthRefreshLocks.get(lockKey);
        if (existing) {
          await existing;
        } else {
          const pRefresh = (async () => {
            const refreshed = await oauth.refreshToken(creds);
            auth.credentials = refreshed as any;
            await saveHubConfig({ stateDir: state.stateDir, config: state.config });
          })().finally(() => {
            state.oauthRefreshLocks.delete(lockKey);
          });
          state.oauthRefreshLocks.set(lockKey, pRefresh);
          await pRefresh;
        }
      }

      return oauth.getApiKey(auth.credentials as any);
    }
  }

  return getEnvApiKey(p);
}

function parseJson<T>(value: any, fallback: T): T {
  if (value == null) return fallback;
  if (typeof value === "string") {
    const trimmed = value.trim();
    if (!trimmed) return fallback;
    try {
      return JSON.parse(trimmed) as T;
    } catch {
      return fallback;
    }
  }
  return value as T;
}

function sanitizeFilename(name: string) {
  const base = path.posix.basename(name);
  return base.replace(/[^a-zA-Z0-9._-]+/g, "_");
}

function normalizeRelativePath(p: string): string | null {
  if (!p) return null;
  if (p.includes("\0")) return null;
  if (path.isAbsolute(p)) return null;
  const norm = path.posix.normalize(p).replace(/^(\.\.(\/|\\|$))+/, "");
  if (norm.startsWith("..")) return null;
  return norm;
}

function normalizeOptionalString(v: unknown): string | undefined {
  if (typeof v !== "string") return undefined;
  const trimmed = v.trim();
  return trimmed ? trimmed : undefined;
}

function normalizePermissionLevel(v: unknown): "default" | "full" | null {
  const raw = typeof v === "string" ? v.trim().toLowerCase() : "";
  if (raw === "default") return "default";
  if (raw === "full") return "full";
  return null;
}

function isLikelyContextOverflowError(message: string): boolean {
  const m = String(message ?? "").toLowerCase();
  if (!m) return false;
  if (m.includes("context_length_exceeded")) return true;
  if (m.includes("maximum context length")) return true;
  if (m.includes("context window")) return true;
  if (m.includes("prompt is too long")) return true;
  if (m.includes("input is too long")) return true;
  if (m.includes("too many tokens")) return true;
  if (m.includes("token limit")) return true;
  if (m.includes("context") && (m.includes("too long") || m.includes("length") || m.includes("exceed"))) return true;
  return false;
}

function normalizeHpcStatus(v: unknown): HpcStatus | undefined {
  if (!v || typeof v !== "object") return undefined;
  const obj = v as any;

  return {
    partition: typeof obj.partition === "string" ? obj.partition : undefined,
    account: typeof obj.account === "string" ? obj.account : undefined,
    qos: typeof obj.qos === "string" ? obj.qos : undefined,
    runningJobs: typeof obj.runningJobs === "number" ? Math.max(0, Math.floor(obj.runningJobs)) : 0,
    pendingJobs: typeof obj.pendingJobs === "number" ? Math.max(0, Math.floor(obj.pendingJobs)) : 0,
    limit: normalizeHpcTres(obj.limit),
    inUse: normalizeHpcTres(obj.inUse),
    available: normalizeHpcTres(obj.available),
    updatedAt: typeof obj.updatedAt === "string" ? obj.updatedAt : new Date().toISOString(),
  };
}

function normalizeHpcTres(v: unknown): HpcTres | undefined {
  if (!v || typeof v !== "object") return undefined;
  const obj = v as any;
  const out: HpcTres = {};
  if (typeof obj.cpu === "number" && Number.isFinite(obj.cpu)) out.cpu = Math.max(0, Math.floor(obj.cpu));
  if (typeof obj.memMB === "number" && Number.isFinite(obj.memMB)) out.memMB = Math.max(0, Math.floor(obj.memMB));
  if (typeof obj.gpus === "number" && Number.isFinite(obj.gpus)) out.gpus = Math.max(0, Math.floor(obj.gpus));
  if (out.cpu == null && out.memMB == null && out.gpus == null) return undefined;
  return out;
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
