import XCTest
@testable import LabOSCore

@MainActor
final class AppStoreSettingsTests: XCTestCase {
    func testGatewaySettingsAreNormalizedTrimmedAndPersisted() {
        let suiteName = "LabOSCoreTests.\(UUID().uuidString)"
        guard let defaults = UserDefaults(suiteName: suiteName) else {
            XCTFail("Unable to create isolated UserDefaults suite")
            return
        }
        defaults.removePersistentDomain(forName: suiteName)
        defer { defaults.removePersistentDomain(forName: suiteName) }

        let store = AppStore(bootstrapDemo: false, userDefaults: defaults)
        store.saveGatewaySettings(wsURLString: "127.0.0.1:8787", token: "  abc123 \n")

        XCTAssertEqual(store.gatewayWSURLString, "ws://127.0.0.1:8787/ws")
        XCTAssertEqual(store.gatewayToken, "abc123")

        let store2 = AppStore(bootstrapDemo: false, userDefaults: defaults)
        XCTAssertEqual(store2.gatewayWSURLString, "ws://127.0.0.1:8787/ws")
        XCTAssertEqual(store2.gatewayToken, "abc123")
    }

    func testHpcSettingsAreTrimmedAndPersisted() {
        let suiteName = "LabOSCoreTests.\(UUID().uuidString)"
        guard let defaults = UserDefaults(suiteName: suiteName) else {
            XCTFail("Unable to create isolated UserDefaults suite")
            return
        }
        defaults.removePersistentDomain(forName: suiteName)
        defer { defaults.removePersistentDomain(forName: suiteName) }

        let store = AppStore(bootstrapDemo: false, userDefaults: defaults)
        store.saveHpcSettings(partition: "  gpu  ", account: "  lab\t", qos: "  normal\n")

        XCTAssertEqual(store.hpcPartition, "gpu")
        XCTAssertEqual(store.hpcAccount, "lab")
        XCTAssertEqual(store.hpcQos, "normal")

        let store2 = AppStore(bootstrapDemo: false, userDefaults: defaults)
        XCTAssertEqual(store2.hpcPartition, "gpu")
        XCTAssertEqual(store2.hpcAccount, "lab")
        XCTAssertEqual(store2.hpcQos, "normal")
    }
}

